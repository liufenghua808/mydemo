let fullTipbox = document.querySelector('.full-tip-box');
let fullTiptext = document.querySelector('.tip-text');
let{test,startMove}=tools;
function fullBox(val){
    fullTiptext.innerHTML =val;
    startMove({obj:fullTipbox,
                json:{
                    top:0
                },
                durtion:500,
                fx:'bounceOut',
                cb(){
                    setTimeout(()=>{
                        startMove({
                            obj:fullTipbox,
                            json:{
                                top:-40
                            },
                            durtion:300,
                            fx:'bounceOut'
                        })
                    },1000)
                }
    })
}