(function(){ //匿名函数自执行 防止与外界污染
    let head = document.querySelector('#head').offsetHeight;//获取fbox到body的距离
    let folders = document.querySelector('.folders');//获取fbox到body的距离
    let f_empty = document.querySelector('.f-empty');//获取fbox到body的距离
    let breadmenu = document.querySelector('.breadmenu').offsetHeight; //获取面包屑的高度
    let iH = document.documentElement.clientHeight;//获取浏览器可视区的距离
    folders.style.height = iH-head-breadmenu+'px'; //fbox的高度等于 浏览器的可视区的高度-面包屑的高度-head的高度
    f_empty.style.height = iH-head-breadmenu+'px'; //fbox的高度等于 浏览器的可视区的高度-面包屑的高度-head的高度
    window.onresize = function(){
        //当浏览器改变大小时 重新获取可视区的高度
        let h = document.documentElement.clientHeight;
        folders.style.height = h-head-breadmenu+'px';
        f_empty.style.height = h-head-breadmenu+'px';
    }
})()