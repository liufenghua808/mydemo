//获取元素
let folders = document.querySelector('.folders');
let fempty = document.querySelector('.f-empty');
let breadNav = document.querySelector('.bread-nav');
let fBox = document.querySelector('#fBox');
let checkedAll = document.querySelector('#checkedAll');
let treeMenu = document.querySelector('.tree-menu');
//解构工具方法
let {
    getChild,
    getParent,
    getParents,
    po,
    duang
} = tools;
//声明一个全局id
let globalId = 0;

function render(id) {//渲染页面
    folders.innerHTML = '';//渲染时先清空内容
    globalId = id * 1;//数据中data[globalId]
    let html = '';//直播拼接模板字符串
    let ary = getChild(globalId);//获取当前id为0的子集  子集的pid =上一级的id
    if (ary) {//如果数组部位空
        fempty.style.display = 'none';//让背景图片隐藏
        checkedAll.className = ary.every(item => item.checked) ? 'checked' : '';//全选按钮根据数据的checked的属性值来判断 如果全部为true则全选
        ary.forEach((item) => { //遍历数组 有多少项 生成多少个文件夹
            html += `<div index="${item.id}" class="${item.checked?"file-item active":"file-item"}">
                        <img src="img/folder-b.png" alt="" ondblclick="dbl(${item.id})"/>
                        <span class="folder-name">${item.title}</span>
                        <input type="text" class="editor"/>
                        <i class="${item.checked?"checked":""}" onclick="events(this,${item.id})"></i>
                    </div>`;
            //字符串模板拼接，设置div的自定义属性index 
            //给图片绑定双击事件，双击时调用函数
            //给i标签绑定单击事件 单击时传参this(this指向i标签) 传item的id
        })
            //
        folders.innerHTML = html;
    }
    return ary;//返回ary
}
render(0);
//封装i标签的单击事件
function events(btn, ele) {//双击时触发的事件
    if (btn.classList.contains('checked')) {//设置开关
        data[ele].checked = false;
        btn.parentNode.className = "file-item";//让i的父元素div初始默认样式
    } else {
        data[ele].checked = true;
        btn.parentNode.classList.add('active');//让i的父元素div设置选中样式
    }
    render(globalId);//操作完数据后重新渲染页面
}
//treelist
renderTree(0);

function renderTree(num) {
    let html = `<ul> 
                    <li> 
                        <div class="tree-title tree-ico open">
                            <span><i></i>${data[num].title}</span>
                        </div>
                    </li>`
    let arr = getChild(num);
    if (arr.length) {
        html += `<ul style="padding-left:15px">
            ${
                arr.map(item=>{
                    let sclass = getChild(item.id).length?'tree-title tree-ico close':'tree-title tree-ico-none';
                    return (`<li index =${item.id}> 
                        <div class="${sclass}">
                            <span><i></i>${item.title}</span>
                        </div>
                    </li>`
                    )
                }).join('')
            }
        </ul>`;
    }
    html += `<ul/>`;
    treeMenu.innerHTML = html;
    return html;
}
treeMenu.onclick = function(ev){
    if(ev.target.tagName ==='SPAN'){
        let li =ev.target.parentNode.parentNode;
        let id  =li.getAttribute('index')*1;
        if(id){
            globalId = id;
            renderBreadNav();
            render(id);
            if(!li.children[0].classList.contains('tree-ico-none')){//先过滤文件夹下没有子集的
                //进来的文件夹有子集 如果div没有close类名为true 有true 为false
                let o =!li.children[0].classList.toggle('close')
                renderChild(li,id,o);
            }else{
                fempty.style.display ='block';
                let arr =getChild(globalId);
                checkedAll.classList.remove('checked')
                
            }
        }
        // console.log(!li.children[0].classList.toggle('close'));
        
    }
}
function renderChild(li,id,onoff){
    if(onoff){
        li.children[0].classList.add('open');
        li.children[0].classList.remove('close');
    }else{
        li.children[0].classList.add('close');
        li.children[0].classList.remove('open');
    }

    if(li.lastElementChild.tagName !=='UL'){
        let ary = getChild(id);
        console.log(ary)
        let html =`<ul style="padding-left:15px">`;
        if(ary.length && onoff){
            html+=`${
                ary.map(item=>{
                    let sclass = getChild(item.id).length?'tree-title tree-ico close':'tree-title tree-ico-none';
                    return (
                        `<li index="${item.id}">
                            <div class="${sclass}">
                                <span><i></i>${item.title}</span>
                            </div>
                        </li>`
                    )
                }).join('') 
            }`
        html +=`</ul>`;
        li.innerHTML += html;
        }
    }else{
        let uls = li.querySelectorAll('ul');
        if(onoff){
            li.children[1].style.display ='block';
        }else{
            for(let i=0;i<uls.length;i++){
                uls[i].style.display ='none';
                uls[i].previousElementSibling.className = 'tree-title tree-ico close';
            }
        }
    }
}

//封装img图片双击事件

function dbl(id) {//此时的id等于 子集的id双击img时 看父级下还有没有子文件夹
    let ary = render(globalId) //
    let arr = getChild(id);//获取子集
    if (arr && arr.length) {//如果子集存在
        render(id); //重新渲染页面
    } else {
        folders.innerHTML = '';//没有子集 清空页面内容
        fempty.style.display = 'block'; //显示图片
        globalId = id;    //让创建的文件在父级下面而不是在同级
    }
    checkedAll.className = ''; //双击时清空选中状态 
    ary.forEach(item => item.checked = false);//操作数据
    renderBreadNav();//渲染面包屑
}
//新建文件夹
create.onclick = createFile;

function createFile() {
    //创建一个文件夹
    let html = '';
    fempty.style.display = 'none';
    html += `<div class="file-item active"">
                <img src="img/folder-b.png" alt=""/>
                <span class="folder-name"></span>
                <input type="text" class="editor" />
                <i class=""></i>
          </div>`

    //拼接字符串模板
    folders.innerHTML += html;
    //获取元素
    let input = document.querySelector('#fBox .folders').lastElementChild.getElementsByTagName('input')[0];
    let span = document.querySelector('#fBox .folders').lastElementChild.getElementsByTagName('input')[0].previousElementSibling;
    //新建文件夹时 输入框默认显示 聚焦 文件名为新建文件夹
    input.style.display = 'block';
    input.value = '新建文件夹';
    input.select();
    //当失去焦点时
    input.onblur = function () {
        let v = this.value;//获取输入的内容
        let arr = getChild(globalId);//获取当前目录的文件夹
        let result = arr.some(item => item.title === v);//检查文件名是否重复
        let id = +new Date;//生成文件夹的id
        if (!result) {//文件名名称不重复时
            //操作DOM
            // span.innerHTML =this.value;
            // this.value='';
            // this.style.display ='none';
            // this.parentNode.classList.remove('active');
            //操作数据
            data[id] = {
                id, //id为时间戳
                pid: globalId, //pid为全局id 如果双击了 则为双击后的id
                title: v, //文件夹名称为输入的名字
                checked: false //默认为未选择
            }
        } else {
            let v2 = v;
            let num = 0;
            while (result) {
                v2 = v2.replace(/\(\d+\)/, '') + `(${++num})`;
                result = arr.some(item => item.title === v2);
            }
            data[id] = {
                title: v2,
                id,
                pid: globalId,
                checked: false
            }
        }
        console.log(globalId);
        render(globalId);//重新渲染
        renderTree(0); //渲染列表
        fullBox('新建文件夹成功!!');
    }
}

//面包屑
function renderBreadNav() {
    //面包屑 只有一层时 span 两层以后 arr的最后一个为span模板 其余的为a标签模板
    let html = '';
    console.log(globalId)
    arr = getParents(globalId);
    arr.forEach((item, i, all) => {
        if (i != all.length - 1) { //i不等于arr的最后一项时
            html += `<a href="javascript:;" data-id="${item.id}">${item.title}</a>`
            //绑定自定义属性 
        } else {
            html += `<span>${item.title}</span>`;
        }
    })
    //渲染面包屑
    breadNav.innerHTML = html;

    //点击面包屑
    breadNav.onclick = function (ev) {
        if (ev.target.tagName === 'A') {
            //通过事件委托 点击父级时找到 点击的目标为a标签
            let arr = getChild(globalId);
            //点击面包屑全部清空框选 全双 单选 状态
            arr.forEach(item => item.checked = false);
            render(ev.target.getAttribute('data-id'))
            renderBreadNav();
            checkedAll.className = '';
        }
    }
}
renderBreadNav();

//选框
let checkedNum = 0;

function move() {
    //画框 鼠标按下 移动 鼠标抬起
    fBox.onmousedown = function (ev) {
        if (ev.target.classList.contains('file-item') || ev.target.parentNode.classList.contains('file-item')) {//在文件夹中拖拽 无效 当前元素中拖拽 或者 上级中拖拽无效
            return false;
        }
        let arr = getChild(globalId);
        arr.forEach(item => {
            item.checked = false;
        })
        render(globalId);
        let div = document.createElement('div');
        div.className = 'kuang';
        let l = ev.pageX;
        let t = ev.pageY;
        fBox.appendChild(div);
        
        fBox.onmousemove = function (ev) {
            checkedNum = 0;
            let disx = fBox.offsetLeft;
            let disy = po(fBox).top;
            let w = ev.pageX - l + 'px'; //盒子的宽度等于 移动前后的坐标差
            let h = ev.pageY - t + 'px';//盒子的高度等于 移动前后的坐标差
            div.style.width = Math.abs(ev.pageX - l) + 'px';
            div.style.height = Math.abs(ev.pageY - t) + 'px';
            div.style.left = Math.min(ev.pageX - disx, l - disx) + 'px';
            div.style.top = Math.min(ev.pageY - disy, t - disy) + 'px';
            // div.style.top = Math.min(ev.pageY-disy,t)+'px';    
            ev.returnValue = false;
            let eles = document.querySelectorAll('.file-item')//获取所有的文件夹
            for (let i = 0; i < eles.length; i++) {
                if (duang(div, eles[i])) {//检测是否碰撞上了
                    data[eles[i].getAttribute('index')].checked = true;
                    checkedNum++;
                } else {
                    data[eles[i].getAttribute('index')].checked = false;
                }
            }
            if (eles.length == checkedNum) { //如果定义的num等于获取到元素的长度 那么为全部框选
                checkedAll.className = 'checked'; //className等于选中状态
            } else {
                checkedAll.className = 'none'; //否则为未全选状态
            }
            render(globalId);//重新渲染页面
        }
        document.onmouseup = function () {
            fBox.onmousemove = document.onmouseup = null; //当鼠标抬起时解绑鼠标事件
            div.style.width = div.style.height = 0;//盒子的高度和宽度还原
            div.remove();//移除div元素
        }
    }
}
move();

//全选
checkedAll.onclick = function (ev) {
    let arr = getChild(globalId);
    // if(arr.length<1){
    //     this.classList.remove('checked')
    //     arr.forEach(item => {
    //         item.checked = false;
    //     })
        
    //     console.log('len<1');
    // }else{
    //     if (ev.target.classList.toggle('checked')) {
    //         arr.forEach(item => {
    //             item.checked = true;
    //         })
    //     } else {
    //         arr.forEach(item => {
    //             item.checked = false;
    //         })
    //     }
    // }
    let bool = checkedAll.classList.toggle('checked');
    arr.forEach(item=>item.checked =bool?true:false)
    
    render(globalId);
    if(arr.length<1){
        this.classList.remove('checked');
        fempty.style.display ='block';
    }
}
//删除文件夹
let tanbox = document.querySelector('#tanbox');
let delbtn = document.querySelector('#del');
let close = document.querySelector('.close-ico');
let conf = document.querySelector('.conf-btn');
let btns = conf.querySelectorAll('a');
let confirm = btns[0];
let cancel = btns[1];

delbtn.onclick = function () {
    let arr = getChild(globalId);
    let ary = arr.filter(item => item.checked);
    let len = arr.filter(item => item.checked).length;
    if (len > 0) {
        tanbox.style.display = 'block';
    } else {
        fullBox('请选择删除的文件')
    }
    confirm.onclick = function () {
        arr.forEach(item => {
            if (item.checked) {
                delete data[item.id];
                tanbox.style.display = 'none';
            }
        })
        ary.forEach(item => {
            item.checked = false;
            // data[item.id].checked = false;
        })

        render(globalId);
        if (arr.length == len) {
            checkedAll.className = '';
        }
        fullBox('删除完毕');
    }
    cancel.onclick = close.onclick = function () {
        tanbox.style.display = 'none';
    }
}
//rename重命名

let rename = document.querySelector('#rename');
rename.onclick = function () {
    change();
}

function change() {
    let ary = getChild(globalId);
    let arr = ary.filter(item => item.checked);
    let len = arr.length;
    console.log(len)
    if (len != 1) {
        fullBox('请选择重命名的文件');
    } else {
        let input = document.querySelector('.folders i[class="checked"]').previousElementSibling;
        let span = document.querySelector('.folders i[class="checked"]').previousElementSibling.previousElementSibling;
        input.style.display = 'block';
        input.value = span.innerHTML;
        span.style.display = 'none';
        input.select();
        input.onblur = function () {
            console.log('失去焦点');
            let v = this.value.trim();
            if (v === arr[0].title) return;
            if (!v) {
                fullBox('请输入文件名');
                return;
            }
            let id = arr[0].id;
            //过滤出不是当前选中的文件夹
            let ary = getChild(globalId).filter(item => item.id !== id)
            //文件夹是否重名
            let end = ary.some(item => item.title === v);
            if (!end) {//不重名
                data[id].title = v;
            } else {//重名
                let v2 = v;
                let num = 0;
                while (end) {
                    v2 = v2.replace(/\(\d+\)/, '') + `(${++num})`;
                    end = ary.some(item => item.title === v2);
                }
                data[id].title = v2;
            }
            render(globalId);
            fullBox('重命名成功');
        }
    }
}
//移动文件夹
let modalTree = document.querySelector('.modal-tree');
let content = document.querySelector('.content')
let remove = document.querySelector('#remove');
let ok = modalTree.querySelector('.ok');
let mclose = modalTree.querySelector('.icon_close');
let mcancel = modalTree.querySelector('.cancel');
let id = 0;
let o = false;
remove.onclick = function(){
    let ary = getChild(globalId);
    let arr = ary.filter(item=>item.checked);
    let len = arr.length;
    if(len<1){
        fullBox('请选择移动的文件');
        return;
    }
    modalTree.style.display ='block';
    content.innerHTML = renderTree(0);
    content.onclick = function(ev){
        if(ev.target.tagName ==='SPAN'){
            o = false;
            let li =ev.target.parentNode.parentNode;
            let spans = content.querySelectorAll('span');
            for(let i =0;i<spans.length;i++){
                spans[i].style.background = '';
            }
            ev.target.style.background ='skyblue';
            id = li.getAttribute('index')*1;
            if(id){
                if(arr.some(item=>item.id ==id)){
                    fullBox('非法选择1');
                    o = true;
                    return;
                }
                if(!li.children[0].classList.contains('tree-ico-none')){
                    let o = !li.children[0].classList.toggle('close');
                    renderChild(li,id,o);
                }
            }
        }
    }
}
ok.onclick = function(){
    if(o){
        fullBox('非法操作2');
        return;
    }
    let ary =getChild(globalId);
    let arr = ary.filter(item=>item.checked);
    let len =arr.length;
    let onoff = false;
    if(len<1)return;
    if(onoff){
        fullBox('非法操作3');
        return;
    }else{
        arr.forEach(item=>{
            item.pid=id;
            item.checked = false;
        });
        render(globalId);
        renderTree(0);
    }
    modalTree.style.display ='none';
}
mcancel.onclick = mclose.onclick= function(){
    modalTree.style.display ='none';
}
