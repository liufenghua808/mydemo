const modalTree = document.querySelector('.modal-tree');
const content = modalTree.querySelector('.content');
const ok = modalTree.querySelector('.ok');
const cancel = modalTree.querySelector('.cancel');

let id = 0; //为了记录移动的id
let o = false; //判断是否为非法操作
//移动到
remove.onclick = function(){
    //获取页面的数据
    let ary = getChild(globalId);
    //过滤，checked属性为true，选中的文件夹
    let arr = ary.filter(item=>item.checked);
    //定义变量=数组的长度
    let len = arr.length;
    //判断小于1
    if(len < 1){
        //弹窗
        fullbox('请选择要移动的文件');
        return ;
    }
//显示
    modalTree.style.display = 'block';
    //里边的内容=调用树形菜单
    content.innerHTML = renderTree(0);

    //点击移动到的树形菜单中
    content.onclick = function(ev){
        //判断单击的是不是span
        if(ev.target.tagName === 'SPAN'){
            o = false;//重新设置一次false
            let li = ev.target.parentNode.parentNode;  //li=点击的父亲的父亲节点

            let span = content.getElementsByTagName('span');

            //把所有的span的背景色清掉
            for(let i=0;i<span.length;i++){
                span[i].style.background = '';
            }
            //把当前点击的span的背景色加上
            ev.target.style.background = '#ccc';

            id = li.dataset.id*1;  //获取到移动到的id
            if(id){
                //移动到的id有没有和选中的id重名   arr数组中有没有和点击的id重名的
                if(arr.some(e=>e.id === id)){
                    //重名即非法操作
                    fullbox('非法选择');
                    o = true;
                    return;
                }
                //生成ul
                if(!li.children[0].classList.contains('tree-ico-none')){
                    let o = !li.children[0].classList.toggle('close')
                    renderChild(li,id,o);
                }
            }
        }
    }


}

//点击确定
ok.onclick = function(){
    //刚才点击移动到的span时，是否有非法操作
    if(o){
        fullbox('非法选择');
        return;
    };
    //id 为点击的
    let ary = getChild(globalId);
    let arr = ary.filter(item=>item.checked);
    let len = arr.length;
    let onoff = false;
    if(len < 1 )return;



    if(onoff){
        //移动不合法
        fullbox('非法操作');
    }else{
        //开始移动，循环遍历数组
        arr.forEach(ele=>{
            ele.pid = id;
            ele.checked = false;
        });
        //调用渲染数据
        render(globalId);
        //左侧的树形菜单，渲染数据
        renderTree(0);
    }
    //移动到隐藏起来
    modalTree.style.display = 'none';
}
//取消，框也隐藏起来
cancel.onclick = function(){
    modalTree.style.display = 'none';
}