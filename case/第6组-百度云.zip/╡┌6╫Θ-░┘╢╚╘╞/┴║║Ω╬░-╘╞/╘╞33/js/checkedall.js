checkedAll.onclick=function(){
    //
    let bool = checkedAll.classList.toggle('checked');
   //定义变量获取当前页面的数据
    let ary = getChild(globalId);
    //循环遍历数组
    ary.forEach(item=>{
        //checked赋值为true或false
        item.checked = bool?true:false;
    });
    //渲染页面
    render(globalId);
}
