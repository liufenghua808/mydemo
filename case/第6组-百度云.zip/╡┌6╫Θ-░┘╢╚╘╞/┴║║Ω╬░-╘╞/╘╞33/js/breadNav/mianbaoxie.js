//结构函数，获取tools,js文件的getParents，和getParent方法
let {getParents,getParent} = tools;


//生成面包屑
//定义方法
function renderBreadNav(){
    //定义字符串
    let html = '';
    //面包屑数组。获取一堆的父级
    let ary = getParents(globalId);
//遍历
    ary.forEach((item,i,all)=>{
        //索引不等于数组长度-1
        if(i != all.length-1){
            //用自定义的方式去存储每个标签的对应的id
            html += `<a data-id="${item.id}" href="javascript:;">${item.title}</a>`;
        }else{
            //字符串拼接
            html += `<span>${item.title}</span>`;
        }
    });

    breadNav.innerHTML = html;
}

//点击面包屑的时候，把对应的id获取出来,赋值globalId
breadNav.onclick = function(ev){
    //单击的当前元素tagName=A
    if(ev.target.tagName === 'A'){
        //console.log(globalId);
        //定义ary接收数据
        let ary = getChild(globalId);
        //遍历数组，将checked =false
        ary.forEach(item=>item.checked = false);
        //渲染数据
        render(ev.target.getAttribute('data-id'));
        //调用自身方法
        renderBreadNav();
        //只要点击了面包屑就把checked值清除。
        checkedAll.className = '';
    }
}


//调用方法
renderBreadNav();

// console.log();

// console.log(getParents(4));




