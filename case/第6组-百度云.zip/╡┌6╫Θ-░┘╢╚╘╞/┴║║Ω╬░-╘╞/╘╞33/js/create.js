//点击，新建
create.onclick = function () {
    //图片，不显示
    fempty.style.display = 'none'
    //创建，节点
    let div = document.createElement('div')
    div.className = 'file-item'
    let img = document.createElement('img')
    img.src = 'img/folder-b.png'
    let input = document.createElement('input');
    //将input,默认值设为‘新建文件夹’
    input.className = "editor";
    input.value = '新建文件夹';
    let is = document.createElement('i');
    div.append(img);
    div.append(input);
    div.append(is);

    folders.appendChild(div);
    //将input设置为显示
    input.style.display = 'block';
    //input内容选中，获得焦点
    input.select();

    //input失去焦点触发
    input.onblur = function () {
        //事件this指向当前input
        let v = this.value;
        //获取同级所有数据
        let ary = getChild(globalId)

        //判断是否重名
        let resault = ary.some(item => item.title === v)
        //给id赋值
        let id = +new Date;
        //未重名
        if (!resault) {
            data[id] = {
                title: v,
                id,
                pid: globalId,
                checked: false
            }
        } else {
            //重命名
            let v2 = v;
            let num = 0
            //循环判断，是否重名，不重名退出循环
            while (resault) {
                v2 = v2.replace(/\(\d+\)/, '') + `(${++num})`
                resault = ary.some(item => item.title === v2);
            }
            data[id] = {
                title: v2,
                id,
                pid: globalId,
                checked: false
            }
        }
        //渲染数据
        render(globalId);
        //弹窗
        fullbox('新建文件夹成功');

    }
}