//获取存放点击完，为空的图片
const  fempty = document.querySelector('.f-empty');
//存储id
let globalId = 0;
//掉用tools.js 文件的getChild
let {getChild} = tools;

//渲染数据render方法
function render(id) {
    //
    globalId = id*1;
    //每次渲染，将folders 的内容置为空
    folders.innerHTML = '';
    //定义ary获取当前页面的数据
    let ary = getChild(globalId);
    //判断ary有值就遍历
    if (ary) {
        //渲染前将图片不显示
        fempty.style.display='none'
        //判断checkedAll的className赋值为checked或者空（选中赋值checked）
        checkedAll.className=ary.every(e=>e.checked)?'checked':'';
        //遍历ary数组
        ary.forEach((ele, i) => {
            //建立div img span input is
            let div = document.createElement('div');
            div.className = 'file-item';
            //存数据的id到盒子上
            div.dataset.id=ele.id;
            let img = document.createElement('img');
            img.src = 'img/folder-b.png';
            //双击图片
            img.ondblclick = function () {
                //获取当前层级的数组
                let ary2 = getChild(ele.id);
                //点击进去，没有子集，显示图片
                if (ary2 && ary2.length) {
                    render(ele.id)
                } else {
                    //显示图片
                    fempty.style.display = 'block'
                    //将id赋给globalId
                    globalId = ele.id;
                    folders.innerHTML = ''
                }
                //全选文件，的时候清除全选
                checkedAll.className=''
                //循环遍历ary,当前对象的checked赋值为false
                ary.forEach(item=>item.checked=false)
                //调用面包屑
                renderBreadNav()
            };
            let span = document.createElement('span');
            span.innerHTML = ele.title;
            span.className = 'folder-name';
            //可以对span进行编辑
            span.contentEditable=true;
            let input = document.createElement('input');
            input.className = 'editor';
            input.value = ele.title;
            let is = document.createElement('i');
            //判断checked属性，是true或false，给is的className赋值为checked活在这''显示是否选中
            is.className=ele.checked?'checked':'';
            //is 单击事件
            is.onclick=function(){
                //单击对它的checked的值进行切换
                data[ele.id].checked=this.classList.toggle('checked')
               //渲染数据
                render(globalId)
            }
            //将元素节点添加到盒子
            div.append(img);
            div.append(span);
            div.append(input);
            div.append(is);
            //将盒子添加到页面
            folders.appendChild(div)
        });
    }}
    //调用方法，渲染页面
        render(0);


