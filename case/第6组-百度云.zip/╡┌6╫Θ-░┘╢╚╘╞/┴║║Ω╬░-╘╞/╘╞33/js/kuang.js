//获取tools文件中的po和duang方法
let {po,duang} = tools;
//获去kuang元素
const kuang = document.querySelector('.kuang');
//定义边量，用于存储碰撞了几个
let checkedNum = 0;
//鼠标按下事件

fBox.onmousedown = function(ev){
//
    if(ev.target.classList.contains('file-item') || ev.target.parentNode.classList.contains('file-item')){
        return false;
    }



    //点击空白处，把所有文件checked状态清楚
    let ary = getChild(globalId)
    ary.forEach(item=>item.checked=false)
    render(globalId)

    let disX = ev.pageX - fBox.offsetLeft;
    let {top} = po(fBox);
    let disY = ev.pageY - top; //+ floders.scrollTop;//一会再解释
    // console.log(ev.pageY);

    kuang.style.display = 'block';
    kuang.style.left = disX + 'px';
    kuang.style.top = disY + 'px';

    fBox.onmousemove = function(ev){
        checkedNum = 0;
        let w = Math.abs((ev.pageX - fBox.offsetLeft) - disX);
        let h = Math.abs((ev.pageY-top) - disY );
        kuang.style.width = w + 'px';
        kuang.style.height = h + 'px';

        let l = Math.min(disX,(ev.pageX - fBox.offsetLeft));
        let t = Math.min(disY,(ev.pageY-top));
        kuang.style.left = l + 'px';
        kuang.style.top = t + 'px';

        let fileItem = document.querySelectorAll('.file-item');

        fileItem.forEach((ele,i)=>{
            if(duang(kuang,ele)){
                data[ele.dataset.id].checked = true;
                checkedNum ++;
            }else{
                data[ele.dataset.id].checked = false;
            }
        });

        if(checkedNum === fileItem.length){
            // console.log('全选');
            checkedAll.className = 'checked';
        }else{
            // console.log('不全选');
            checkedAll.className = '';
        }

        render(globalId);
        return false;

    }
  document.onmouseup = function(){
        kuang.style.display = 'none';
        kuang.style.width =0;
        kuang.style.height=0;
        fBox.onmousemove = fBox.onmouseup = null;
    }
}
