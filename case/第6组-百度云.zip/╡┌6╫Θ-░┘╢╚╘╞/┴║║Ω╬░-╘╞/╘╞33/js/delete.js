//单击删除
del.onclick=function(){
    //定义变量接收页面的数据
    let ary = getChild(globalId)

    let a = document.querySelectorAll('.conf-btn a');
    let x = document.querySelector('.close-ico');
    //页面中checked为真的长度
    let len = ary.filter(ele=>ele.checked).length
    //如果长度大于0
    if(len>0){
        //弹框，确定要删除文件吗？显示
        tanbox.style.display='block'
    }else{
        //调用定义方法，弹框
        fullbox('请选择删除文件')
    }
    //当前盒子下a的第一个元素确认  单击事件
    a[0].onclick=function(){
        //数组，遍历
        ary.forEach(item=>{
            //判断当前的checked属性是true还是false
            if(item.checked){
                //为true，则删除
                delete data[item.id]
            }
        })
        //渲染数据
        render(globalId)
        //确认删除的弹框不显示
        tanbox.style.display='none'
    }
    //取消按钮  单击事件   x也为取消
    a[1].onclick = x.onclick = function(){
        //确认删除的弹框不显示
        tanbox.style.display = 'none';
    }
}