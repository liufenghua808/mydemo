//点击重命名，单击事件
rename.onclick=function (){
    //定义边量接收当前数据
    let ary=getChild(globalId)
    //定义边量，过滤checked属性，为true的
    let arr=ary.filter(item=>item.checked)
    // 定义变量，存储过滤出来的数组的长度
    let len = arr.length
    //长度判断
    if(len!==1){
        //如果不是一个，弹框，选择一个文件
        fullbox('请选择一个文件')
    }else{
        let is = document.querySelector('i[class="checked"]');
        let input = is.previousElementSibling;
        let span = input.previousElementSibling;
        //输入框显示
        input.style.display = 'block';
        //span 隐藏
        span.style.display = 'none';
        //输入框获得焦点，并文字选中
        input.select();

         //输入框失去焦点
        input.onblur = function(){
            //定义变量，等于修改后的内容，去除空格
            let v = this.value.trim();
            //如果修改的名字和数据的名字一样，说明没有修改
            if(v === arr[0].title)return;
            //如果为空
            if(!v){
                //弹框
                fullbox ('请输入文件名');
                return;
            };
            //定义id变量=当前改名元素
            let id = arr[0].id;
            //同级所有数据,并且排除选中数据
            let ary = getChild(globalId).filter(el=>el.id !== id);

            //如果为true说明重命名
            let resault = ary.some(item => item.title === v);

            if(!resault){
                //没有重命名，修改数据中title的值
                data[id].title = v;
            }else{
                //重命名
                let v2 = v;
                let num = 0;
                while(resault){
                    //给文件名加括号数字
                    v2 = v2.replace(/\(\d+\)/,'') + `(${++num})`;
                   //判断是否相等
                    resault = ary.some(item=>item.title === v2);
                }
                // console.log(v2);
                //将值赋给title
                data[id].title = v2;
            }
            //渲染数据
            render(globalId);
            //弹框修改成功
            fullbox ('重命名成功');
        }
    }
}
