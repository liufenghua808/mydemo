console.log(data);


const  f = document.querySelector('.f-empty');
let globalId = 0; //存储id的

function render(id){
    globalId = id*1;
    folders.innerHTML = '';
    //如果有子级，就渲染
    let ary = getChild(globalId);
    if(ary && ary.length){
        f.style.display = 'none';
        checkedAll.className = ary.every(e=>e.checked)?'checked':'';
        ary.forEach((ele,i)=>{
           
            let div = document.createElement('div');
            div.className = ele.checked?'file-item active':'file-item';
            div.dataset.id = ele.id;
            let img = document.createElement('img');
            img.src = 'img/folder-b.png';
            img.ondblclick = function(){    
                let arr = getChild(ele.id);
                if(arr && arr.length){ 
                    render(ele.id);
                }else{
                    f.style.display = 'block';
                    globalId = ele.id;
                    folders.innerHTML = '';
                }

                checkedAll.className = '';
                ary.forEach(item=>item.checked=false);
                renderBread();
            }
            let span = document.createElement('span');
            span.className = 'folder-name';
            span.innerHTML = ele.title;
            span.contentEditable = true;
            let input = document.createElement('input');
            input.className = "editor";
            input.value = ele.title;
            let is = document.createElement('i');
            is.className = ele.checked?'checked':'';

            is.onclick = function(){
                data[ele.id].checked = this.classList.toggle('checked');
                render(globalId);
            }

            div.append(img);
            div.append(span);
            div.append(input);
            div.append(is);
            folders.appendChild(div);
        });

        // createst(id);
        // 无文件显示图片
        const fo = document.querySelectorAll('#fBox .folders .file-item');
        console.log(fo);
        if (fo.length === 0) {
            f.style.display = 'block'
            f.style.width = '1659px';
            f.style.height = '758px';
            f.style.margin = 'auto'
        } else {
            f.style.display = 'none';
        }
        
    }else{
        console.log('jin');
        f.style.display = 'block';
        checkedAll.className = '';
    }
    renames();
        deles();
        xuan();
}

render(0);



//刷新
reash.onclick = function () {
    window.location.reload();
}


//重命名
function renames() {
    let divs = document.querySelectorAll('#fBox .folders .file-item');//文件夹盒子
    let cf = document.querySelectorAll('#fBox .folders .file-item .folder-name');
    let ins = document.querySelectorAll('#fBox .folders .file-item .editor');//
    let cfss = document.querySelectorAll('#fBox .folders .file-item>i');//选中未选中

    for (let i = 0; i < cfss.length; i++) {
        let cfd = cfss[i];
        cfd.onmousedown = function () {
            if (cfd.className === 'checked') { //选中未选中
                cfd.className = 'unchecked';
            } else {
                cfd.className = 'checked';

            }

        }

    }

    for (let i = 0; i < cf.length; i++) {
        let c = cf[i];
        let inst = ins[i];
        let divss = divs[i];

        //双击重命名
        c.ondblclick = function () {
            inst.value = c.innerHTML;
            inst.style.display = 'block';
            c.style.display = 'none';
            inst.focus();
            inst.select();

        }
        //失去焦点完成命名
        inst.onblur = function () {
            c.innerHTML = inst.value;
            inst.style.display = 'none';
            c.style.display = 'block';
        }
    }

    rename.onclick = function () {

        for (let i = 0; i < cfss.length; i++) {
            let c2 = cf[i];
            let inst2 = ins[i];
            let divss2 = divs[i];
            if (cfss[i].className === 'checked') {
                console.log(2);
                inst2.value = c2.innerHTML;
                inst2.style.display = 'block';
                c2.style.display = 'none';
                inst2.focus();
                inst2.select();
            }

        }
    }

}




//删除
function deles() {
    let fe = document.querySelectorAll('#fBox .folders .file-item');//文件夹盒子
    let cfs = document.querySelectorAll('#fBox .folders .file-item>i');//选中未选中
    console.log('cfs', cfs);

    for (let i = 0; i < cfs.length; i++) {
        let cfd = cfs[i]
        cfd.onmousedown = function () {
            if (cfd.className === 'checked') { //选中未选中
                cfd.className = 'unchecked';
            } else {
                cfd.className = 'checked';
            }

        }

    }
    let btn = document.querySelectorAll('#tanbox .conf-btn>a')[0];
    let can = document.querySelectorAll('#tanbox .conf-btn>a')[1];

    //删除
    del.onclick = function () {
        tanbox.style.display = 'block'
        let att = [];
        for (let i = 0; i < cfs.length; i++) {
            if (cfs[i].className === 'checked') {
                att.push(i);
                btn.onclick = function () {
                    for (let j = 0; j < att.length; j++) {
                        fe[att[j]].remove();
                    }
                    tanbox.style.display = 'none';
                }
            }
        }
        can.onclick = function () {
            tanbox.style.display = 'none';
        }
        sss.onclick = function () {
            tanbox.style.display = 'none';
        }
    }
}



// 选框
let { po, duang } = tools;
const kuang = document.querySelector('.kuang');
let checkedNum = 0;//计碰撞个数

//点击空白处的时候，把所有的文件夹checked状态清除
let ary = getChild(globalId);
ary.forEach(item => item.checked = false);
render(globalId);

function xuan() {

    fBox.onmousedown = function (ev) {

        if (ev.target.classList.contains('file-item') || ev.target.parentNode.classList.contains('file-item')) {
            return false;
        }

        let disX = ev.pageX - fBox.offsetLeft;
        let { top } = po(fBox);
        let disY = ev.pageY - top;


        kuang.style.display = 'block';
        kuang.style.left = disX + 'px';
        kuang.style.top = disY + 'px';

        fBox.onmousemove = function (ev) {
            checkedNum = 0;
            let w = Math.abs((ev.pageX - fBox.offsetLeft) - disX);
            let h = Math.abs((ev.pageY - top) - disY);
            kuang.style.width = w + 'px';
            kuang.style.height = h + 'px';

            let l = Math.min(disX, (ev.pageX - fBox.offsetLeft));
            let t = Math.min(disY, (ev.pageY - top));
            kuang.style.left = l + 'px';
            kuang.style.top = t + 'px';

            let fileItem = document.querySelectorAll('.file-item');

            fileItem.forEach((ele, i) => {
                //当创建元素很多之后，会出现滚动条，所以加上了folders滚动条的高度
                if (duang(kuang, ele, folders.scrollTop)) {
                    data[ele.dataset.id].checked = true;
                    checkedNum++;
                } else {
                    data[ele.dataset.id].checked = false;
                }
            });

            if (checkedNum === fileItem.length) {
                // console.log('全选');
                checkedAll.className = 'checked';
            } else {
                // console.log('不全选');
                checkedAll.className = '';
            }

            render(globalId);
            // console.log('move');
            return false;
        }
        document.onmouseup = function () {
            kuang.style.display = 'none';
            kuang.style.width = kuang.style.height = 0;
            fBox.onmousemove = document.onmouseup = null;
        }

    }


}









