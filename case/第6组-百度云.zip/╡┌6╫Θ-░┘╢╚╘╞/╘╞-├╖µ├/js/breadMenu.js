
//面包屑
class BreadMenu extends Floder{
    constructor() {
        super();
        this.items = document.querySelectorAll('#fBox .file-item');
        this.breadNav = document.querySelector('.bread-nav');
        this.folder = document.getElementsByClassName('folders')[0];
        this.checkedAll = document.getElementById('checkedAll');
        this.parents = [];
        this.breadEvents();
        this.renderBread(0);

    }

    getBreadData(id) {//传入当前的id 找到所有的祖先 放到一个数组中
        if (!data[id])return;
        let p=data[id].pid;//当前对应的父级的id 也就是面包屑的最后一级
        this.parents.unshift(data[id]);
        if(data[p]){
            this.getBreadData(p);
        }


    }
    getChild(pid) {//传入pid 找到当前匹配pid的所有子集 放到数组中
        if (!data[pid]) return null;
        let ary = [];
        for (let k in data) {
            if (data[k].pid == pid) {
                ary.push(data[k]);
            }
        }
        return ary;
    }

    renderBread(id) {//渲染导航 找当前id对应的所有父级
        //let p=data[id].pid;//当前对应的父级的id 也就是面包屑的最后一级
        this.getBreadData(id);
        let html = ``;
        if(this.parents.length==0)return;
        this.parents.forEach((item, i) => {
            if (i === this.parents.length - 1) {
                html += `<span data-id="${item.id}">${item.title}</span>`
            } else {
                html += `<a href="javascript:;" data-id="${item.id}">${item.title}</a>`
            }
        });
        this.breadNav.innerHTML=html;
        this.parents=[];
    }

    breadEvents() {
        let that = this;
        //全选
        this.checkedAll.onclick = function () {
            if (this.className === 'checked') {//当前选中状态
                this.className = '';
                that.items.forEach(e => {
                    e.classList.remove('active');
                    e.lastElementChild.className = '';
                });
                that.checkedNum=0;
            } else {//变成选中
                this.className = 'checked';
                that.items.forEach(e => {
                    e.classList.add('active');
                    e.lastElementChild.className = 'checked';
                });
                that.checkedNum=that.items.length;
            }
        };
        //面包屑点击事件
        this.breadNav.onclick=function (e) {
            if(e.target.tagName==='A'){
                that.checkedAll.className='';
                let curId=e.target.getAttribute('data-id')*1;
                let f=new Floder();
                f.renderLoader(curId);
                that.renderBread(curId);
                that.items=f.items;

            }

        }

    }
}
let menu = new BreadMenu();
