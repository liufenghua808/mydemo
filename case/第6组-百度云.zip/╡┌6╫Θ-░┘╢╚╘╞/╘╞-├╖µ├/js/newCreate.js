//新建文件夹
class newCreate extends Floder {
    constructor() {
        super();
        this.create = document.getElementById('create');
        this.items = document.querySelectorAll('#fBox .file-item');
        this.folder = document.getElementsByClassName('folders')[0];
        this.fullTip = document.querySelector('.full-tip-box');
        // this.startMove = utils.startMove;
        this.eventsCreate();
    }

    fullBox(val) {
        let {startMove}=utils;
        let that = this;
        this.fullTip.innerHTML = val;
        startMove({
            obj: that.fullTip,
            json: {
                top: 0
            },
            duration: 500,
            fx: 'bounceOut',
            cb(){
                setTimeout(() => {
                    startMove({
                        obj: that.fullTip,
                        json: {
                            top: -40
                        },
                        duration: 300
                    }, 1000)
                })
            }


        })


    }

    eventsCreate() {
        let that = this;
        //点击新建
        this.create.onclick = function () {
            if (that.empty.style.display == 'block') {
                that.folder.innerHTML = '';
                that.empty.style.display = 'none';
            }
            let newObj = {};
            let div = document.createElement('div');
            div.className = 'file-item';
            let img = document.createElement('img');
            img.src = "img/folder-b.png";
            let span = document.createElement('span');
            span.className = "folder-name";
            span.innerText = '新建文件夹';
            let input = document.createElement('input');
            input.className = "editor";
            let i = document.createElement('i');
            div.append(img, span, input, i);
            that.folder.appendChild(div);
            let pidSpan = document.querySelector('.bread-nav span');
            let pid = pidSpan.getAttribute('data-id');
            input.style.display = 'block';
            input.value = span.innerText;
            input.select();
            let titleAry = [];
            for (let k in data) {
                titleAry.push(data[k].title);
            }

            input.onblur = function () {
                let curVal = this.value;
                let flag = titleAry.some(e => e == curVal);
                if (!flag) {//没有重名
                    newObj.id = +new Date();//获取时间戳作为新建文件夹的id
                    newObj.pid = pid;
                    newObj.title = curVal;
                    newObj.checked = false;
                    data[newObj.id] = newObj;
                } else {
                    let num = 0;
                    let v = curVal;
                    while (flag) {
                        v = v.replace(/\(\d+\)/, '') + '(' + (++num) + ')';
                        flag = titleAry.some(e => e === v);
                    }
                    newObj.id = +new Date();//获取时间戳作为新建文件夹的id
                    newObj.pid = pid;
                    newObj.title = v;
                    newObj.checked = false;
                    data[newObj.id] = newObj;
                }
                let r = new Floder();
                r.renderLoader(pid);

                that.fullBox('新建文件夹成功');


            }

        }
    }

}
let create = new newCreate();

//删除
class Delete {
    constructor() {
        this.del = document.getElementById('del');
        this.tanbox = document.getElementById('tanbox');
        this.close = this.tanbox.querySelector('.close-ico');
        this.conmit=this.tanbox.querySelectorAll('.conf-btn a')[0];
        this.cancel=this.tanbox.querySelectorAll('.conf-btn a')[1];
        this.events();
    }

    events() {
        let that = this;
        //点击删除按钮
        this.del.onclick = function () {
            that.tanbox.style.display = 'block';


        };
        //点击确认删除按钮
        this.conmit.onclick=function () {
            let items=document.querySelectorAll('.folders .file-item.active');
            console.log(items);
            if(items.length===0){
                let f=new newCreate();
                f.fullBox('请至少选中一个元素！');
                that.tanbox.style.display = 'none';
                return;
            }
            items.forEach(e=>{
                //选中 准备删除的元素
                    let {id}=e.dataset;
                    // data[id].checked=false;
                    delete data[id];
            })
            let {id}=document.querySelector('.breadmenu span').dataset;
            let f=new Floder();
            f.renderLoader(id);
            that.tanbox.style.display = 'none';
            
        }

        this.cancel.onclick=this.close.onclick = function () {
            that.tanbox.style.display = 'none';
        }

    }
}
let d = new Delete();