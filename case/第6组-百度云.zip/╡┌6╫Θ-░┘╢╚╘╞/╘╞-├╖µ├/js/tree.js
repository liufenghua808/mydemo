// function setTree(data) {
//     let cloneData = JSON.parse(JSON.stringify(data));//克隆一份数据
//     for (let p in cloneData) {//循环每一个
//         let ary=[];
//         for (let c in cloneData) {//循环每一个
//             if (cloneData[c].pid == cloneData[p].id) {
//                 ary.push(cloneData[c]);
//             }
//         }
//         ary.length>0?cloneData[p].children=ary:null;
//     }
//     for(let h in cloneData){
//         return cloneData[h].id==0? cloneData[h]:null;
//     }
// }
// let treeData=setTree(data);//转换成树形结构的数据

class Cloud {
    constructor() {
        // this.section=document.getElementById('section');
        this.treeMenu = document.getElementsByClassName('tree-menu')[0];
        this.data = data;
    }

    setTree(data) {//转换成树形结构的数据
        let cloneData = JSON.parse(JSON.stringify(data));//克隆一份数据
        for (let p in cloneData) {//循环每一个
            let ary = [];
            for (let c in cloneData) {//循环每一个
                if (cloneData[c].pid == cloneData[p].id) {
                    ary.push(cloneData[c]);
                }
            }
            ary.length > 0 ? cloneData[p].children = ary : null;
        }
        let ary = Object.values(cloneData);
        return ary.filter(item => {
            return item.id == 0;
        });


    }

    renderNav() {
        let treeData = this.setTree(this.data);
        let html = ``;


        // let oUl=document.createElement('ul');
        html += `<ul>
                        <li>
                        
                        </li>
                    </ul>`


    }

}
// let c=new Cloud();
// c.renderNav();
class Tree{
    constructor(){
        this.parentId=-1;
        this.oUl=document.getElementById('oUl');
        this.events();
    }
    renderTree(pid){
        let temp = '';
        for (let k in data) {
            if (data[k].pid == pid) {
                temp += `<li data-id="${k}" class="${k==0?'open':''}">`;
                let subTitle = this.renderTree(data[k].id);
                temp += `<div class="tree-title ${subTitle === '' ? 'tree-ico-none' : 'tree-ico'}">
                            <span><i></i>${data[k].title}</span>
                        </div>`;
                if (subTitle !== '') {
                    temp += `<ul>${subTitle}</ul>`;
                }
                temp += `</li>`;
            }
        }
        return temp;
    }
    events(){
        this.oUl.innerHTML = this.renderTree(this.parentId);
        this.list=document.querySelectorAll('#oUl li div');
        this.list.forEach(e=>{
            //给每一个div添加点击事件
            e.onclick=function () {
                let li=this.parentNode;
                let id=li.dataset.id*1;//每个li上面存的id
                if(!this.classList.contains('tree-ico-none')){
                    li.classList.toggle('open');
                };
                let f=new Floder();
                f.renderLoader(id);
                let b=new BreadMenu();
                b.renderBread(id);

            }
        })
    }
}
let t=new Tree();



// let parentId = -1;
// function render(data, pid) {
//     let temp = '';
//     for (let k in data) {
//         if (data[k].pid == pid) {
//             temp += `<li>`;
//             let subTitle = `${render(data, data[k].id)}`;
//             temp += `<div class="tree-title ${subTitle === '' ? 'tree-ico-none' : 'tree-ico'}">
//                             <span><i></i>${data[k].title}</span>
//                         </div>`;
//             if (subTitle !== '') {
//                 temp += `<ul>${subTitle}</ul>`;
//             }
//             temp += `</li>`;
//         }
//     }
//     return temp;
// }
// let oUl = document.getElementById('oUl');

