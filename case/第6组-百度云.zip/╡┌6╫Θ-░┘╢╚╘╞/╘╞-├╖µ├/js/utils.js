let utils = (function () {
    //判断数据类型
    function isType(data) {
        let str = Object.prototype.toString.call(data);
        let reg = /^\[object ([a-zA-Z]+)\]$/g;
        return reg.exec(str)[1].toLocaleLowerCase();

    }

    //类数组转数组
    function listToAry(likeAry) {
        let newAry = [];
        try {
            newAry = [].slice.call(likeAry, 0);
            return newAry;
        } catch (e) {
            for (let i = 0; i < likeAry.length; i++) {
                newAry[newAry.length] = likeAry[i];
            }
            return newAry;
        }
    }

    //JSON字符串转JSON对象
    function jsonParse(jsonStr) {
        return 'JSON' in window ? JSON.parse(jsonStr) : eval('(' + jsonStr + ')');
    }

    //找指定元素哥哥节点
    function prevEle(ele) {
        let prev = ele.previousSibling;
        while (prev && !(prev.nodeType == 1)) {
            prev = ele.previousSibling;
        }
        return prev;
    }

    //找指定元素所有的哥哥节点
    function prevAll(ele) {
        let prev = ele.previousSibling;
        let all = [];
        while (prev) {
            if (!(prev.nodeType == 1)) {
                all.unshift(prev);
            }
            prev = ele.previousSibling;
        }
        return all;
    }

    //获取css样式
    function getCss(curEle, attr) {
        let val, reg;
        if ('getComputedStyle' in window) {
            val = getComputedStyle(curEle)[attr];
        } else {//ie 低版本
            if (attr === 'opacity') {
                val = curEle.currentStyle['filter'];
                //'alpha(opacity=10)'
                reg = /alpha\(opacity=((?:\d|[1-9]\d)(?:\.\d+)?)\)/;
                let temp = reg.exec(val);
                val = temp ? temp[1] / 100 : 1;

            } else {
                val = curEle.currentStyle[attr];
            }
        }
        //去掉单位
        reg = /^[+-](\d|[1-9]\d+)(\.\d+)?(px|rem|pt|em)$/g;
        return reg.text(val) ? parseFloat(val) : val;

    }

    function setCss(curEle, attr, val) {
        if (attr === 'opacity') {
            curEle.style.opacity = val;
            curEle.style.filter = 'alpha(opacity=' + val * 100 + ')';
            return;
        }
        if (attr === 'float') {
            curEle.style.cssFloat = val;
            curEle.style.styleFloat = val;
            return;
        }
        let reg = /width|height|top|bottom|left|right|((margin|padding)(top|bottom|left|right))/;
        if (reg.test(attr)) {
            if (!isNaN(val)) {
                val = val + 'px';
            }
        }
        curEle.style[attr] = val;
    }

    function css(curEle, attr, val) {
        if (typeof attr == 'object') {
            for (let k in attr) {
                setCss(curEle, k, attr[k]);
            }
        } else {
            setCss(curEle, attr, val);
        }
        if (val === 'undefined') {
            return getCss(curEle, attr);
        }
    }

    /*滚轮事件兼容性处理
     @param curEle 当前需要滚轮的元素
     @param fn 滚轮触发的函数
     * */
    function addWheel(curEle, fn) {
        if (curEle.onmousewheel === null) {//谷歌
            curEle.onmousewheel = whell;
        } else {//火狐
            curEle.addEventListener('DOMMouseScroll', whell);

        }
        function whell(e) {
            let flag;
            console.log(e.wheelDelta);
            if (e.wheelDelta) {
                flag = (e.wheelDelta > 0 ? true : false);
                console.log(flag);
            } else {
                flag = e.detail < 0 ? true : false;
            }

            fn && fn(flag);
        }
    }

    /*碰撞
     @param ele1 当前拖拽元素
     @param ele2 被碰撞元素
     * */
    function collision(ele1, ele2,scrollT,scrollL) {
        scrollL=scrollL||0;
        scrollT=scrollT||0;
        let l1 = ele1.offsetLeft+scrollL;
        let r1 = l1 + ele1.offsetWidth;
        let t1 = ele1.offsetTop+scrollT;
        let b1 = t1 + ele1.offsetHeight;
        let l2 = ele2.offsetLeft;
        let r2 = l2 + ele2.offsetWidth;
        let t2 = ele2.offsetTop;
        let b2 = t2 + ele2.offsetHeight;
        if (r1 < l2 || b1 < t2 || l1 > r2 || t1 > b2) {
            return false;//没有碰上
        } else {
            return true;//碰上了
        }

    }
    function offset(ele) {//求距离页面最左端和最顶端的偏移值
        let l = ele.offsetLeft;
        let t = ele.offsetTop;
        let p = ele.offsetParent;
        while (p.tagName !== 'BODY') {
            l += p.offsetLeft;
            t += p.offsetTop;
            p = p.offsetParent;
        }
        return {l, t}
    }
    function shake(opt){
        //默认配置
        //为什么要用默认配置？
        //是因为有些参数不想传
        let opts = {
            obj:null,
            attr:'left',
            endNum:10,
            cb:function(){}
        }

        //有配置走配置，没配置走默认
        Object.assign(opts,opt);

        //如果传了一个cb的属性,还要判断是否为函数，因为只有函数才能调用。
        if(opt.cb && typeof opt.cb !== 'function'){
            opts.cb = function(){}
        }

        // console.log(opts)

        // return;

        let num = 0;
        let begin = parseFloat(getComputedStyle(opts.obj)[opts.attr]);
        let arr = [];
        for(let i=opts.endNum;i>0;i-=2){
            arr.push(i,-i);
        }
        arr.push(0);
        //    console.log(arr);

        //    return;
        clearInterval(opts.obj.timer);
        opts.obj.timer = setInterval(() => {
            opts.obj.style[opts.attr] = begin + arr[num] + 'px';
            num ++;
            if(num === arr.length){
                num = 0;
                clearTimeout(opts.obj.timer);
                //当运动完成之后再执行cb这个函数
                opts.cb();
                // console.log('马某在跳跃');
            }
        }, 16.7);
    }
    var Tween = {
        linear: function (t, b, c, d){  //匀速
            return c*(t/d) + b;
        },
        easeIn: function(t, b, c, d){  //加速曲线
            return c*(t/=d)*t + b;
        },
        easeOut: function(t, b, c, d){  //减速曲线
            return -c *(t/=d)*(t-2) + b;
        },
        easeBoth: function(t, b, c, d){  //加速减速曲线
            if ((t/=d/2) < 1) {
                return c/2*t*t + b;
            }
            return -c/2 * ((--t)*(t-2) - 1) + b;
        },
        easeInStrong: function(t, b, c, d){  //加加速曲线
            return c*(t/=d)*t*t*t + b;
        },
        easeOutStrong: function(t, b, c, d){  //减减速曲线
            return -c * ((t=t/d-1)*t*t*t - 1) + b;
        },
        easeBothStrong: function(t, b, c, d){  //加加速减减速曲线
            if ((t/=d/2) < 1) {
                return c/2*t*t*t*t + b;
            }
            return -c/2 * ((t-=2)*t*t*t - 2) + b;
        },
        elasticIn: function(t, b, c, d, a, p){  //正弦衰减曲线（弹动渐入）
            if (t === 0) {
                return b;
            }
            if ( (t /= d) == 1 ) {
                return b+c;
            }
            if (!p) {
                p=d*0.3;
            }
            if (!a || a < Math.abs(c)) {
                a = c;
                var s = p/4;
            } else {
                var s = p/(2*Math.PI) * Math.asin (c/a);
            }
            return -(a*Math.pow(2,10*(t-=1)) * Math.sin( (t*d-s)*(2*Math.PI)/p )) + b;
        },
        //弹性运动
        elasticOut: function(t, b, c, d, a, p){    //正弦增强曲线（弹动渐出）
            if (t === 0) {
                return b;
            }
            if ( (t /= d) == 1 ) {
                return b+c;
            }
            if (!p) {
                p=d*0.3;
            }
            if (!a || a < Math.abs(c)) {
                a = c;
                var s = p / 4;
            } else {
                var s = p/(2*Math.PI) * Math.asin (c/a);
            }
            return a*Math.pow(2,-10*t) * Math.sin( (t*d-s)*(2*Math.PI)/p ) + c + b;
        },
        elasticBoth: function(t, b, c, d, a, p){
            if (t === 0) {
                return b;
            }
            if ( (t /= d/2) == 2 ) {
                return b+c;
            }
            if (!p) {
                p = d*(0.3*1.5);
            }
            if ( !a || a < Math.abs(c) ) {
                a = c;
                var s = p/4;
            }
            else {
                var s = p/(2*Math.PI) * Math.asin (c/a);
            }
            if (t < 1) {
                return - 0.5*(a*Math.pow(2,10*(t-=1)) *
                    Math.sin( (t*d-s)*(2*Math.PI)/p )) + b;
            }
            return a*Math.pow(2,-10*(t-=1)) *
                Math.sin( (t*d-s)*(2*Math.PI)/p )*0.5 + c + b;
        },
        backIn: function(t, b, c, d, s){     //回退加速（回退渐入）
            if (typeof s == 'undefined') {
                s = 1.70158;
            }
            return c*(t/=d)*t*((s+1)*t - s) + b;
        },
        backOut: function(t, b, c, d, s){
            if (typeof s == 'undefined') {
                s = 3.70158;  //回缩的距离
            }
            return c*((t=t/d-1)*t*((s+1)*t + s) + 1) + b;
        },
        backBoth: function(t, b, c, d, s){
            if (typeof s == 'undefined') {
                s = 1.70158;
            }
            if ((t /= d/2 ) < 1) {
                return c/2*(t*t*(((s*=(1.525))+1)*t - s)) + b;
            }
            return c/2*((t-=2)*t*(((s*=(1.525))+1)*t + s) + 2) + b;
        },
        bounceIn: function(t, b, c, d){    //弹球减振（弹球渐出）
            return c - Tween['bounceOut'](d-t, 0, c, d) + b;
        },
        //自由落体
        bounceOut: function(t, b, c, d){
            if ((t/=d) < (1/2.75)) {
                return c*(7.5625*t*t) + b;
            } else if (t < (2/2.75)) {
                return c*(7.5625*(t-=(1.5/2.75))*t + 0.75) + b;
            } else if (t < (2.5/2.75)) {
                return c*(7.5625*(t-=(2.25/2.75))*t + 0.9375) + b;
            }
            return c*(7.5625*(t-=(2.625/2.75))*t + 0.984375) + b;
        },
        bounceBoth: function(t, b, c, d){
            if (t < d/2) {
                return Tween['bounceIn'](t*2, 0, c, d) * 0.5 + b;
            }
            return Tween['bounceOut'](t*2-d, 0, c, d) * 0.5 + c*0.5 + b;
        }
    }
    function startMove(opts){
        let opt = {
            obj:null,
            json:{},
            durtion:1000,
            cb:function(){},
            fx:'linear'
        }

        //有配置走配置，没配置走默认
        Object.assign(opt,opts);
        if(opts.cb && typeof opts.cb !== 'function'){
            opt.cb = function(){}
        }

        let f = opt.fx;
        //存储每个属性的初始值和目标点
        let j = {};
        // 枚举整个json,把每个属性赋值为对象，在对象下又有初始值和目标点
        for(let attr in opt.json){
            if(opt.json.hasOwnProperty(attr)){
                //获取到每个属性的初始值
                let b = parseFloat(getComputedStyle(opt.obj)[attr]);
                let c = 0;
                //获取到每个属性的目标点 类似于{width:{fx:'exx',d:500}}
                if(typeof opt.json[attr] === 'object'){
                    j[attr] = {b}
                    for(let attr2 in opt.json[attr]){
                        j[attr][attr2] = opt.json[attr][attr2];
                    }

                    j[attr].c = j[attr].c - j[attr].b;
                }else{
                    c = opt.json[attr];
                    c = c - b;
                    j[attr] = {
                        b,
                        c
                    };
                }
            }
        }

        let d = opt.durtion;
        let t = 0;


        (function move(){
            opt.obj.timer = requestAnimationFrame(move);
            t += 16.7;
            if(t >= d)t=d;

            for(let attr in j){
                //把默认值赋值给fx，不然都覆盖了
                opt.fx = f;
                opt.fx = j[attr].fx || opt.fx;
                //如果是opacity就不加单位
                if(attr === 'opacity'){
                    opt.obj.style[attr] = Tween[opt.fx](t, j[attr].b,j[attr].c, d);
                }else{
                    opt.obj.style[attr] = Tween[opt.fx](t, j[attr].b,j[attr].c, d) + 'px';
                }
            }

            if(t === d){
                cancelAnimationFrame(opt.obj.timer);
                opt.cb();
            }
        })();
    }


    return {
        isType,
        listToAry,
        jsonParse,
        prevEle,
        prevAll,
        getCss,
        setCss,
        css,
        addWheel,
        collision,
        offset,
        shake,
        startMove

    }
})()