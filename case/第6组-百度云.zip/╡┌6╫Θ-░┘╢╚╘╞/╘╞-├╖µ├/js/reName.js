class ReName{
    constructor(){
        this.rename=document.getElementById('rename');
        this.folders=document.querySelector('.folders');
        this.events();
    }
    events(){
        let that=this;
        this.rename.onclick=function () {
            let items = that.folders.querySelectorAll('.file-item.active');//选中的item
            if(items.length>1||items.length==0){
                let n = new newCreate();
                n.fullBox('只能选中一个文件夹！！！');
                return;
            }else {//有且只能有一个
                let i=that.folders.querySelector('i[class="checked"]');
                let input=i.previousElementSibling;
                let span=input.previousElementSibling;
                span.style.display='none';
                input.style.display='block';
                input.value=span.innerText;
                input.focus();

                console.log(input)
                input.onblur=function () {
                    this.style.display = 'none';
                    span.style.display='block';
                    let val = this.value;
                    if (val == this.previousElementSibling.innerText) {
                        return;
                    }

                    let curId = this.parentNode.getAttribute('data-id');
                    for (let k in data) {
                        if (data[k].title == val) {//重名
                            let n=new newCreate();
                            n.fullTip('重名了！');
                            return;
                        }
                    }
                    //没有重名 就让修改的内容复制给当前id的title
                    this.previousElementSibling.innerText = val;
                    data[curId].title = val;
                    // input.style.display='block';
                    span.innerText=val;

                    // let f=new Floder();
                    // f.renderLoader(curId);
                    let b=new BreadMenu();
                    b.renderBread(data[curId].pid);
                    let t=new Tree();
                    t.renderTree(-1);
                    let r=new renderModel();

                    
                }
                
            }



        }
    }
}
let r=new ReName();