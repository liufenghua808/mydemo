class Move {
    constructor() {
        this.remove = document.getElementById('remove');
        this.modelTree = document.querySelector('.modal-tree');
        this.modelCon = document.querySelector('.modal-tree .content');
        this.folderName = this.modelTree.querySelector('.folderName');
        this.close = this.modelTree.querySelector('.icon_close');
        this.confirm = this.modelTree.querySelector('.footer .ok');
        this.cancel = this.modelTree.querySelector('.footer .cancel');
        this.events();
    }

    renderModel() {
        let ul = document.createElement('ul');
        let t = new Tree();
        ul.innerHTML = t.renderTree(-1);
        this.modelCon.appendChild(ul);
        this.list = document.querySelectorAll('.content li div');

    }

    events() {
        this.renderModel();
        let that = this;
        //点击移动到
        this.remove.onclick = function () {
            that.modelTree.style.display = 'block';
        };
        //点击确认移动
        this.confirm.onclick = function () {
            let items = document.querySelectorAll('.folders .file-item.active');//选中的item
            //获取模态框中选中的span
            let curSpan=document.querySelector('.content span.active');
            //获取模态框中选中的li
            let li=curSpan.parentNode.parentNode;
            let id = li.dataset.id*1 ;//模态框每个li上面存的id

            for (let i=0; i<items.length;i++) {
                if (items[i].dataset.id * 1 === id) {
                    let n = new newCreate();
                    n.fullBox('不能移动到本身里面！！！');
                    return;
                }
            }
            items.forEach(e=>{//给每个选中的item的pid设置为点击的这个id 并且渲染到页面中
                data[e.dataset.id].pid=id;
            });
            let f=new Floder();
            f.renderLoader(id);
            let b=new BreadMenu();
            b.renderBread(id);
            let t=new Tree();
            t.renderTree(-1);
            that.modelTree.style.display = 'none';
        };
        //点击取消移动
        this.cancel.onclick = this.close.onclick = function () {
            that.modelTree.style.display = 'none';
        };
        this.list.forEach(e => {
            //给每一个div添加点击事件
            e.onclick = function () {
                let items = document.querySelectorAll('.folders .file-item.active');//选中的item
                let li = this.parentNode;
                let id = li.dataset.id * 1;//模态框每个li上面存的id
                that.list.forEach(ele => {
                    ele.firstElementChild.className = '';
                });
                this.firstElementChild.className = 'active';
                that.folderName.innerHTML = this.firstElementChild.innerText;
                for (let i=0; i<items.length;i++) {
                    if (items[i].dataset.id * 1 === id) {
                        let n = new newCreate();
                        n.fullBox('不能移动到本身里面！！！');
                        return;
                    }
                }
                if (!this.classList.contains('tree-ico-none')) {
                    li.classList.toggle('open');
                }

            }
        })

    }
}
let m = new Move();