class Kuang {
    constructor() {
        this.folder = document.querySelector('.folders');
        this.fBox = document.getElementById('fBox');
        this.fBoxL = utils.offset(this.fBox).l;
        this.fBoxT = utils.offset(this.fBox).t;
        this.checkedAll = document.getElementById('checkedAll');
        this.checkedNum=0;
        this.kuangEvents();
    }

    kuangEvents() {
        let that=this;
        this.folder.onmousedown = function (e) {
            if (e.target.className.includes('file-item') || e.target.parentNode.className.includes('file-item'))return false;
            that.items.forEach(e => {
                e.classList.remove('active');
                e.lastElementChild.className = '';
                that.checkedAll.className=''

            })
            let downX = e.pageX - that.fBoxL;
            let downY = e.pageY - that.fBoxT;

            let kuang = document.createElement('div');
            kuang.style.left = downX + 'px';
            kuang.style.top = downY + 'px';
            kuang.className = 'kuang';
            that.fBox.appendChild(kuang);
            that.folder.onmousemove = function (e) {
                that.checkedNum = 0;
                let moveX = e.pageX - that.fBoxL;
                let moveY = e.pageY - that.fBoxT;
                // moveX>that.folW?moveX=that.folW:null;
                // if(moveX<offsetL){
                //     moveX=offsetL;
                // }else if(moveX>that.folW){
                //     moveX=that.folW;
                // }
                // if(moveY<offsetT){
                //     moveY=offsetT;
                // }else if(moveY>that.folH){
                //     moveY=that.folH;
                // }
                // moveY>that.folH?moveY=that.folH:null;

                let l = Math.min(downX, moveX);
                let t = Math.min(downY, moveY);
                let wid = Math.abs(moveX - downX);
                let hei = Math.abs(moveY - downY);
                // wid>=that.folW?wid=that.folW:null;
                // hei>=that.folH?hei=that.folH:null;
                kuang.style.width = wid + 'px';
                kuang.style.height = hei + 'px';
                if (l < 0) {
                    l = 0;
                } else if (l > that.folW - wid) {
                    l = that.folW - wid;
                }
                if (t < 0) {
                    t = 0;
                } else if (t > that.folH - hei) {
                    t = that.folH - hei;
                }
                kuang.style.left = l + 'px';
                kuang.style.top = t + 'px';
                that.items.forEach(item => {
                    if (utils.collision(kuang, item,that.folder.scrollTop)) {//撞了

                        item.classList.add('active');
                        item.lastElementChild.classList.add('checked');
                        that.checkedNum++;
                    } else {
                        item.classList.remove('active');
                        item.lastElementChild.classList.remove('checked');
                    }
                });
                if (that.checkedNum === that.items.length) {
                    that.checkedAll.className = 'checked';
                }
            }
            document.onmouseup = function () {
                that.fBox.removeChild(kuang);
                that.folder.onmousemove = this.onmouseup = null;
            }
        };

        //点击空白处 取消选中状态
        // this.folder.onclick=function (e) {
        //     console.log(e.target);
        //     if(e.target.tagName.className.includes('file-item')||e.target.parentNode.className.includes('file-item'))return;
        //
        //     that.items.forEach(e=>{
        //         e.classList.remove('active');
        //         e.lastElementChild.className='';
        //     })
        //
        // }
    }
}
let k=new Kuang();