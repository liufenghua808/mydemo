class Floder extends Kuang{
    constructor() {
        super();
        this.empty=document.querySelector('.f-empty');
        this.folder = document.querySelector('.folders');
        // this.kuang = document.getElementsByClassName('kuang')[0];
    }

    getData(pid) {//传入pid 找到当前匹配pid的所有子集 放到数组中
        if (!data[pid]) return null;
        let ary = [];
        for (let k in data) {
            if (data[k].pid == pid) {
                ary.push(data[k]);
            }
        }
        return ary;
    }

//传入id 找到当前匹配id的所有子集 渲染到页面中
    renderLoader(id) {
        let list = this.getData(id);
        if (!list || list.length == 0) {
            this.empty.style.display='block';
            return;
        }else {
            this.empty.style.display='none';
        }
        let html = ``;
        list.forEach(item => {
            html += `<div class="file-item ${item.checked?'active':''}" data-id="${item.id}">
                                <img src="img/folder-b.png" alt="" />
                                <span class="folder-name">${item.title}</span>
                                <input type="text" class="editor"/>
                                <i class="${item.checked?'checked':''}"></i>
                            </div>`
        });
        this.folder.innerHTML = html;

        this.foldersH();

        this.items = document.querySelectorAll('.file-item');

        this.folderName = document.querySelectorAll('.folder-name');
        this.edit = document.querySelectorAll('.editor');
        this.events();
        this.choose();
        this.reName();

    }
    events() {
        let that = this;
        this.folder.ondblclick = function (e) {
            if (e.target.tagName == 'IMG') {
                let id = e.target.parentNode.getAttribute('data-id');
                that.checkedAll.className='';
                that.renderLoader(id);
                let bread=new BreadMenu;
                bread.renderBread(id);
            }
        };

    }

    //点击选中 再点击 就不选中
    choose() {
        let that=this;
        this.items.forEach(item => {
            item.onclick = function (e) {
                if (e.target.tagName == 'SPAN' || e.target.tagName == 'INPUT') return;
                if (this.className.includes('active')) {
                    this.classList.remove('active');
                    this.lastElementChild.classList.remove('checked');
                    that.checkedAll.className ='';
                    return;
                }
                this.classList.add('active');
                this.lastElementChild.classList.add('checked');
                let divs=Array.prototype.slice.call(that.items);
                let flag=divs.some(e=>!e.classList.contains('active'));
                that.checkedAll.className = flag?'':'checked';
            }
        });
    }

    //重命名
    reName() {
        //双击显示修改的input
        this.folderName.forEach(e => {
            e.ondblclick = function () {
                this.nextElementSibling.style.display = 'block';
                this.nextElementSibling.value = this.innerText;
                this.nextElementSibling.focus();
            }
        });
        //失焦查看input中的名字跟data数据中有没有重名的
        this.edit.forEach(e => {
            e.onblur = function () {
                this.style.display = 'none';
                let val = this.value;
                if (val == this.previousElementSibling.innerText) {
                    return;
                }

                let curId = this.parentNode.getAttribute('data-id');
                for (let k in data) {
                    if (data[k].title == val) {//重名
                        let f=new newCreate;
                        f.fullBox('重名了');
                        return;
                    }
                }
                //没有重名 就让修改的内容复制给当前id的title
                this.previousElementSibling.innerText = val;
                data[curId].title = val;
            }

        })
    }

    //计算出当前的folders的高度 如果小于最小高度 就让其等于最小高度
    foldersH() {
        let winH = window.innerHeight;
        this.folW = parseFloat(getComputedStyle(this.folder).width);

        this.folH = parseFloat(getComputedStyle(this.folder).height);
        if (this.folH < winH - this.fBoxT) {
            this.folH = winH - this.fBoxT;
        }
        this.fBox.style.height = this.folH + 'px';
    }

}

let f = new Floder;
f.renderLoader(0);


