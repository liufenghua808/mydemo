// 渲染页面
function render(id){
  // 全局变量globalId
  globalId = id*1;
  folders.innerHTML = '';
  let arr = getChild(globalId);
  // console.log(arr);
  // 如果arr有子级就进行渲染
  if(arr && arr.length){
    fempty.style.display = 'none';
    arr.forEach(ele => {
      // console.log(ele);
      // 创建元素
      let div = document.createElement('div');
      div.className = ele.checked?'file-item active':'file-item';
      div.dataset.id = ele.id;
      let img = document.createElement('img');
      img.src = 'img/folder-b.png';

      // 文件夹双击时，进入文件夹子菜单，没有子菜单的时候
      // 显示无文件的图标
      img.ondblclick = function(){
        let ary = getChild(ele.id);
        if(ary && ary.length){
          render(ele.id);
        }else{
          // console.log(1);
          // 实现最后一层显示图标
          fempty.style.display = 'block';
          // 新建文件夹最后一层时清空数据，并且设置globalId
          globalId = ele.id;
          folders.innerHTML = '';
        }
        checkedAll.className = '';
        arr.forEach(item=>item.checked = false);
        renderBreadNav();
      }

      let span = document.createElement('span');
      span.className = 'folder-name';
      span.innerHTML = ele.title;
      let input = document.createElement('input');
      input.className = 'editor';
      input.value = ele.title;
      let is = document.createElement('i');
      is.className = ele.checked?'checked':'';

      is.onclick = function(){
        // console.log(1);
        data[ele.id].checked = this.classList.toggle('checked');
        // console.log(data[ele.id]);
        render(globalId);
      }


      div.appendChild(img);
      div.appendChild(span);
      div.appendChild(input);
      div.appendChild(is);

      folders.appendChild(div)
    });
  }else{
    fempty.style.display = 'block';
    checkedAll.className = '';
  }
}

render(0)