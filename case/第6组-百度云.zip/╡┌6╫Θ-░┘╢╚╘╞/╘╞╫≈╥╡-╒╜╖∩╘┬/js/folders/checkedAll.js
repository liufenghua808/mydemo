checkedAll.onclick = function(){
  // all返回boolean值，判断是否选中
  let all = checkedAll.classList.toggle('checked');
  let ary = getChild(globalId);
  // console.log(ary);
  ary.forEach(ele => {
    ele.checked = all?true:false;
  });
  render(globalId)
}