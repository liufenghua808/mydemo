
// 统计碰撞文件夹个数
let checkNum = 0;

fBox.onmousedown = function(ev){
    // 点击文件夹时不触发默认行为
    if(ev.target.classList.contains('file-item')||ev.target.parentNode.classList.contains('file-item')){
        return false;
    };

    let arr = getChild(globalId);
    // 点击空白处时，把所有文件夹的checked状态消除
    arr.forEach(ele=>ele.checked = false);
    checkedAll.className = '';
    render(globalId);

    // console.log(arr);
    let disX = ev.pageX - fBox.offsetLeft;
    let {top} = po(fBox);
    let disY = ev.pageY - top;

    kuang.style.display = 'block';
    kuang.style.left = disX + 'px';
    kuang.style.top = disY + 'px';

    // 移动时出发事件
    fBox.onmousemove = function(ev){
        checkNum = 0;
        let w = Math.abs(ev.pageX - fBox.offsetLeft - disX) ;
        let h = Math.abs(ev.pageY - top - disY);

        kuang.style.width = w + 'px';
        kuang.style.height = h + 'px';

        // 取鼠标按下和移动时鼠标位置较小作为kuang的left和top
        let l = Math.min((ev.pageX - fBox.offsetLeft),disX);
        let t = Math.min((ev.pageY - top),disY);

        kuang.style.left = l + 'px';
        kuang.style.top = t + 'px';

        const fileItem = document.querySelectorAll('.file-item');
        // console.log(fileItem);
        
        // 遍历文件夹
        fileItem.forEach(ele => {
            if(duang(kuang,ele,folders.scrollTop)){
                data[ele.dataset.id].checked = true;
                checkNum ++;
            }else{
                data[ele.dataset.id].checked = false;
            }
        });

        // 全选中时checkAll选中
        if(checkNum === fileItem.length){
            checkedAll.className = 'checked';
        }else{
            checkedAll.className = '';
        }
        render(globalId);
        // return false;
    }
    // 抬起时清除kuang的样式，宽高和onmousemove和onmouseup事件
    document.onmouseup = function(){
        kuang.style.display = 'none';
        kuang.style.width = kuang.style.height = 0;
        fBox.onmousemove = document.onmouseup = null;
    } 
}