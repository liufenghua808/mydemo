create.onclick = function(){
  // 建文件夹时最后一层 fempty 为none
  fempty.style.display = 'none';
  // 点击新建文件夹时创建文件夹
  let div = document.createElement('div');
  div.className = 'file-item';
  let img = document.createElement('img');
  img.src = 'img/folder-b.png';
  let input = document.createElement('input');
  input.className = 'editor';
  input.value = '新建文件夹';
  let i = document.createElement('i');
  
  div.appendChild(img);
  div.appendChild(input);
  div.appendChild(i);

  folders.appendChild(div);
  input.style.display = 'block';
  input.select();

  // input 失焦时创建文件夹数据
  input.onblur = function(){
    let v = this.value;
    // console.log(globalId);
    let arr = getChild(globalId);
    // 若相等说明有重名
    let sameName = arr.some(item => item.title === v)
    let id = +new Date;
    // console.log(id);
    if(!sameName){
      // 没有重名时创建文件夹
      data[id] = {
        title:v,
        id,
        pid:globalId,
        checked:false
      }
    }else{
      // 有重名时用正则替换添加括号
      let v2 = v;
      let num = 0;
      while(sameName){
        v2 = v2.replace(/\(\d+\)/,'') + `(${++num})`;
        sameName = arr.some(item => item.title === v2);
      }

      data[id] = {
        title:v2,
        id,
        pid:globalId,
        checked:false
      }
    }
    render(globalId);
    renderTree(0);
    fullBox('新建文件夹成功')
  }
}