// console.log(rename);
rename.onclick = function(){
  let ary = getChild(globalId);
  let arr = ary.filter(ele=>ele.checked);
  let len = arr.length;
  console.log(len);

  // 判断重命名只能选择一个文件
  if(len!==1){
    fullBox('请选择一个文件')
  }else{
    let i = folders.querySelector('i[class="checked"]');
    let input = i.previousElementSibling;
    let span = input.previousElementSibling;

    input.style.display = 'block';
    span.style.display = 'none';
    input.select();

    input.onblur = function(){
      // 排除空格的情况
      let v = this.value.trim();
      // 名字相同时不执行下面代码
      if(v === arr[0].title) return;
      if(!v){
        fullBox('请输入文件名');
        return;
      };
  
      let id = arr[0].id;
      // console.log(id);
      let ary = getChild(globalId).filter(ele=>ele.id!==id);
      // 重命名
      let resault = ary.some(ele => ele.title === v);

      if(!resault){
        data[id].title = v;
      }else{
        let v2 = v;
        let num = 0;
        while(resault){
          v2 = v2.replace(/\(\d+\)/,'') + `(${++num})`;
          resault = ary.some(ele=>ele.title === v2);
        }
        data[id].title = v2;
      }
      render(globalId);
      renderTree(0);
      fullBox('重命名成功');
    }
  } 
}