del.onclick = function(){
  let ary = getChild(globalId);
  // 获取选中文件夹的个数
  let len = ary.filter(ele=>ele.checked).length;
  // 获取操作元素
  let a = document.querySelectorAll('.conf-btn a');
  let x = document.querySelector('.close-ico');

  // 判断有选中弹出弹窗，没有就弹出fullBox
  if(len > 0){
    tanbox.style.display = 'block';
  }else{
    fullBox('请选择删除文件')
  }

  // 点击确定时
  a[0].onclick = function(){
    ary.forEach(ele => {
      if(ele.checked){
        // console.log(ele.id);
        delete data[ele.id];
      }
    });
    render(globalId);
    renderTree(0);
    tanbox.style.display = 'none';
  }
  a[1].onclick = x.onclick = function(){
    tanbox.style.display = 'none';
  }
}