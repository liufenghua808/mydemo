// 记录移动的id
let id = 0;
// 判断是否为非法操作
let o = false;
move.onclick = function(){
  let ary = getChild(globalId);
  let arr = ary.filter(item=>item.checked);
  let len = arr.length;

  if(len < 1){
    fullBox('请选择要移动的文件');
    return;
  }

  modalTree.style.display = 'block';
  content.innerHTML = renderTree(0);
  
  // console.log(content);
  content.onclick = function(ev){
    // debugger;
    // folderName.innerHTML = data[ev.target.id].title;
    if(ev.target.tagName === 'SPAN'){
      o = false;
      let li = ev.target.parentNode.parentNode;
      console.log(li);
      let span = content.getElementsByTagName('span');

      // 清除背景色
      for(let i = 0;i < span.length;i++){
        span[i].style.background = '';
      }
      ev.target.style.background = '#ccc';

      id = li.dataset.id*1;
      // console.log(id)
      
      // 表头内容
      folderName.innerHTML = data[li.dataset.id].title;

      // 设置有重名无法选择
      if(id){
        if(arr.some(ele=>ele.id == id)){
          fullBox('非法选择');
          o = true;
          return;
        }
        if(!li.children[0].classList.contains('tree-ico-none')){
          let o = !li.children[0].classList.toggle('close')
          renderChild(li,id,o);
        }
      }
    }
  }
}

ok.onclick = function(){
  if(o){
    fullBox('非法选择');
    return;
  };
  let ary = getChild(globalId);
  let arr = ary.filter(item=>item.checked);
  let len = arr.length;
  let onoff = false;
  if(len < 1)return;
  if(onoff){
    fullBox('不可移到当前文件夹');
  }else{
      arr.forEach(ele=>{
          ele.pid = id; 
          ele.checked = false;
      });
      render(globalId);
      renderTree(0);
  }
  modalTree.style.display = 'none';
}
cancel.onclick = icon.onclick = function(){
  modalTree.style.display = 'none';
}