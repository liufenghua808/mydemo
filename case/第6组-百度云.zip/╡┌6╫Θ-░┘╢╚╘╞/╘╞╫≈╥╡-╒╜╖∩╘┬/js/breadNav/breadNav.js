function renderBreadNav(){
  let ary = getParents(globalId);
  // console.log(ary);
  let html = '';
  ary.forEach((ele,i,all) => {
    if(i != all.length-1){
      html += `<a data-id="${ele.id}" href="javascript:;">${ele.title}</a>`;
    }else{
      html += `<span>${ele.title}</span>`;
    }
    breadNav.innerHTML = html;
  });
}

// 点击面包屑把对应的id获取
breadNav.onclick = function(ev){
  if(ev.target.tagName === 'A'){
    let ary = getChild(globalId);
    // 点击时全部checked设置为false
    ary.forEach(ele=>ele.checked = false);
    // 获取if，赋值给globalId
    let id = ev.target.getAttribute('data-id');
    render(id);
    renderTree(0);
    renderBreadNav();
  }
}
renderBreadNav();