// 获取操作元素
const folders = document.querySelector('.folders');
const fempty = document.querySelector('.f-empty');
const breadMenu = document.querySelector('.breadmenu');
const checkedAll = document.querySelector('#checkedAll');
const breadNav = document.querySelector('.bread-nav');
const fullTipBox = document.querySelector('.full-tip-box');
const create = document.querySelector('#create');
const kuang = document.querySelector('.kuang');
const fBox = document.querySelector('#fBox');
const del = document.querySelector('#del');
const move = document.querySelector('#remove');
const rename = document.querySelector('#rename');
const treeMenu = document.querySelector('.tree-menu');
const modalTree = document.querySelector('.modal-tree');
const content = document.querySelector('.content');
const folderName = document.querySelector('.folderName');
const ok = modalTree.querySelector('.ok');
const cancel = modalTree.querySelector('.cancel');
const icon = modalTree.querySelector('.icon_close');

let globalId = 0;// 存储全局变量globalId

// 获取封装方法
let {startMove,getChild,getParent,getParents,po,duang } = tools;

function fullBox(value){
  fullTipBox.innerHTML = value;
  startMove({
    obj:fullTipBox,
    json:{top:0},
    durtion:500,
    fx:'bounceOut',
    cb(){
      setTimeout(() => {
        startMove({
          obj:fullTipBox,
          json:{top:-40},
          durtion:300
        })
      },1000)
    }
  })
}
