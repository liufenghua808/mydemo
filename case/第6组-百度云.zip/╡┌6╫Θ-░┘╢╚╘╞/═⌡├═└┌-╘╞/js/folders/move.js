const modalTree = document.querySelector('.modal-tree');
const content = modalTree.querySelector('.content');
const ok = modalTree.querySelector('.ok');
const cancel = modalTree.querySelector('.cancel');

let id = 0; 
let o = false; 
remove.onclick = function(){
    let ary = getChild(globalId);
    let arr = ary.filter(item=>item.checked);
    let len = arr.length;
    if(len < 1){
        fullbox('请选择要移动的文件');
        return ;
    }

    modalTree.style.display = 'block';
    content.innerHTML = renderTree(0);
    content.onclick = function(ev){
        if(ev.target.tagName === 'SPAN'){
            o = false;
            let li = ev.target.parentNode.parentNode;

            let span = content.getElementsByTagName('span');

            for(let i=0;i<span.length;i++){
                span[i].style.background = '';
            }
            ev.target.style.background = '#ccc';

            id = li.dataset.id*1;  
            if(id){
                if(arr.some(e=>e.id === id)){
                    fullbox('非法选择');
                    o = true;
                    return;
                }
                if(!li.children[0].classList.contains('tree-ico-none')){
                    let o = !li.children[0].classList.toggle('close')
                    renderChild(li,id,o);
                }
            }
        }
    }


}


ok.onclick = function(){

    if(o){
        fullbox('非法选择');
        return;
    };
    let ary = getChild(globalId);
    let arr = ary.filter(item=>item.checked);
    let len = arr.length;
    let onoff = false;
    if(len < 1 )return;
    if(onoff){
        fullbox('非法操作,已报110');
    }else{
        arr.forEach(ele=>{
            ele.pid = id; 
            ele.checked = false;
        });
        render(globalId);
        renderTree(0);
    }
    modalTree.style.display = 'none';
}

cancel.onclick = function(){
    modalTree.style.display = 'none';
}