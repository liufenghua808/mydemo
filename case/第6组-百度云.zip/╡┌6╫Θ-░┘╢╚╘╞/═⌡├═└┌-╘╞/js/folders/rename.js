rename.onclick = function(){
    let ary = getChild(globalId);
    let arr = ary.filter(item=>item.checked);
    let len = arr.length;
    if(len!==1){
        fullbox('请选择一个文件');
    }else{
        let is = folders.querySelector('i[class="checked"]');
        let input = is.previousElementSibling;
        let span = input.previousElementSibling;

        input.style.display = 'block';
        span.style.display = 'none';
        input.select();
        input.onblur = function(){
            let v = this.value.trim();
            if(v === arr[0].title)return;
            if(!v){
                fullbox ('请输入文件名');
                return;
            };
            let id = arr[0].id;
            let ary = getChild(globalId).filter(el=>el.id !== id);

            let resault = ary.some(item => item.title === v);
            
            if(!resault){

                data[id].title = v;
            }else{
              
                let v2 = v;
                let num = 0;
                while(resault){
                    v2 = v2.replace(/\(\d+\)/,'') + `(${++num})`;
                    resault = ary.some(item=>item.title === v2);
                }
              
                data[id].title = v2;
            }
            render(globalId);
            renderTree(0);
            fullbox ('重命名成功');
        }
    }
}

