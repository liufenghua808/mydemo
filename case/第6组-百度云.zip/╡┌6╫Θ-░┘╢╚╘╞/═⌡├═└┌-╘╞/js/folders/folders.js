const  fempty = document.querySelector('.f-empty');

let globalId = 0; //存储id的

function render(id){
    globalId = id*1;
    folders.innerHTML = '';
    let ary = getChild(globalId);
    if(ary && ary.length){
        fempty.style.display = 'none';
        checkedAll.className = ary.every(e=>e.checked)?'checked':'';
        ary.forEach((ele,i)=>{
           
            let div = document.createElement('div');
            div.className = ele.checked?'file-item active':'file-item';
            div.dataset.id = ele.id;
            let img = document.createElement('img');
            img.src = 'img/folder-b.png';
            img.ondblclick = function(){
                console.log(ary);
                //当前层级的数组
                let arr = getChild(ele.id);
                if(arr && arr.length){ //0是假的
                    render(ele.id);
                }else{
                    fempty.style.display = 'block';
                    globalId = ele.id;
                    folders.innerHTML = '';
                }
                checkedAll.className = '';
                //把上一层的数据checked状态设置为false。
                ary.forEach(item=>item.checked=false);
                renderBreadNav();
            }
            let span = document.createElement('span');
            
            span.className = 'folder-name';
            span.innerHTML = ele.title;
            span.contentEditable = true;
            let input = document.createElement('input');
            input.className = "editor";
            input.value = ele.title;
            let is = document.createElement('i');
            is.className = ele.checked?'checked':'';

            is.onclick = function(){
                data[ele.id].checked = this.classList.toggle('checked');
                render(globalId);
            }

            div.append(img);
            div.append(span);
            div.append(input);
            div.append(is);
            folders.appendChild(div);
        });
    }else{
        console.log('jin');
        fempty.style.display = 'block';
        checkedAll.className = '';
    }
}

render(0);