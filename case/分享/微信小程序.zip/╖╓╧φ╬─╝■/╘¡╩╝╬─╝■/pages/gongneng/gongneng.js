// pages/gongneng/gongneng.js
const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    name: app.globalData.name,
    address: app.globalData.address,
    phone: app.globalData.phone,
    ImgUrl:[
      {
        url:"https://xcxapi.dq3c.net/xcxapi/images/xcx-10.jpg"
      },
      {
        url: "https://xcxapi.dq3c.net/xcxapi/images/xcx-11.jpg"
      },
      {
        url: "https://xcxapi.dq3c.net/xcxapi/images/xcx-12.jpg"
      }
    ],
    indicatorDots: true,
    autoplay: true,
    interval: 4000,
    duration: 1000,
    circular: true,
  },
  findmap: function () {
    var that = this
    wx.openLocation({
      latitude: 39.952724851696836,
      longitude: 116.30883615211486,
      name: that.data.name,
      address: that.data.address,
      scale: 28
    })

  },

  findphone: function () {
    var that = this
    wx.makePhoneCall({
      phoneNumber: that.data.phone //仅为示例，并非真实的电话号码
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})