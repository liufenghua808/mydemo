//index.js
//获取应用实例
const app = getApp()

Page({
  // 页面的初始数据：定义的一些变量方法
  data: {
    ImgUrls: [
      {
        url: 'https://xcxapi.dq3c.net/wxsp_ht/images/upload/company/1506414498.jpg'
      },
      {
        url: 'https://xcxapi.dq3c.net/wxsp_ht/images/upload/company/1506414671.jpg'
      },
      {
        url: 'https://xcxapi.dq3c.net/wxsp_ht/images/upload/company/1506414686.jpg'
      },
      {
        url: 'https://xcxapi.dq3c.net/wxsp_ht/images/upload/company/1506414518.jpg'
      },
      {
        url: 'https://xcxapi.dq3c.net/wxsp_ht/images/upload/company/1506414702.jpg'
      },
      {
        url: 'https://xcxapi.dq3c.net/wxsp_ht/images/upload/company/1506414723.jpg'
      }
    ],
    dailishangid: app.globalData.name,
    daili_info:"",
    telephones:"",
    name: app.globalData.name,
    address: app.globalData.address,
    phone: app.globalData.phone,
    indicatorDots: true,
    autoplay: true,
    interval: 4000,
    duration: 1000,
    circular: true

  },
// 监听页面加载、进入页面首先加载此页面
  onLoad: function () {
    var dailishangid = wx.getStorageSync('dailishangid');
    if (dailishangid != null && dailishangid != "") {
      var daili_info = wx.getStorageSync('dailishang_info');
      this.setData({
        dailishangid: wx.getStorageSync('dailishangid'),
        daili_info: daili_info,
        telephones: daili_info.telephones.split(",")
      })
    }
  },

  findmaps: function (event) {
    var daili_info = wx.getStorageSync('dailishang_info');
    console.log(event.currentTarget.dataset)
    wx.openLocation({
      latitude: parseFloat(event.currentTarget.dataset.lat),
      longitude: parseFloat(event.currentTarget.dataset.lng),
      name: daili_info.companyname,
      address: daili_info.address,
      scale: 28
    })

  },

  findmap: function () {
    console.log(111)
    var that = this
    wx.openLocation({
      latitude: 39.952724851696836,
      longitude: 116.30883615211486,
      name: that.data.name,
      address: that.data.address,
      scale: 28
    })

  },
  findxphones:function(event){
      var that = this
      wx.makePhoneCall({
        phoneNumber: event.currentTarget.dataset.phone //仅为示例，并非真实的电话号码
      })      

  },
  findphone: function () {
    var that = this
    var dailishangid = wx.getStorageSync('dailishangid');
    if (dailishangid != null && dailishangid != "") {
      var daili_info = wx.getStorageSync('dailishang_info');
      var phone = daili_info.linkus_telephone;
    } else {
      var phone = that.data.phone;
    }
    wx.makePhoneCall({
      phoneNumber: phone //仅为示例，并非真实的电话号码
    })
  },
})
