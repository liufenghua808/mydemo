// pages/gongxiu/gongxiu.js

Page({

  /**
   * 页面的初始数据
   */

  data: {
    // http_api: app.globalData.http_api,
    cur: 0,
    fenlei_list: null,
    imgList: null,
    f: true,
    http_host: 'https://xcxshop.dq3c.net',
    http_api: 'https://xcxshop.dq3c.net/index.php/api/',
    userInfo: null,
    page:null,
    _id:55,
    weizhi:null
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      cur: 0,
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    var id = 55;
    this.get_itemImg(id);
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var _this =this;
    this.get_fenleiList();
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  show: function (e) {
    var _this = this
    var b = e.currentTarget.dataset.id;
    var _id = e.currentTarget.dataset.c_id;
    // console.log("获取的传送的ID",_id)

    _this.setData({
      cur: b,
      _id: _id,
      weizhi:b
    })
    _this.get_itemImg(_id)

  },
  get_fenleiList: function (e) {
    var _this = this;
    wx.request({
      url: _this.data.http_api + 'casement/index',
      method: 'post',
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      success: function (res) {
        // console.log("获取小程序分类", res.data)
        _this.setData({
          fenlei_list: res.data.list
        })


      }
    })
  },
  get_itemImg: function (id) {
    
    var _this = this;
    var page = 1;
    _this.setData({
      page:page
    })
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: _this.data.http_api + 'product/al',
      data: { id: id, page: page},
      method: 'post',
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      success: function (res) {
        wx.hideLoading();
        // console.log("获取小程序图片", res.data.ggtop)
        if (res.data.ggtop == null) {
          _this.setData({
            
            f: false
          })
        } else {
          _this.setData({
            imgList: res.data.ggtop,
            f: true
          })
        }



      }
    })
  },
  show_img: function (e) {
    console.log("获得图片路径", e.currentTarget.dataset.src)
    var src = e.currentTarget.dataset.src;
    wx.previewImage({
      urls: [src],
    })
  },
  onReachBottom:function(){
    var _this  = this;
    var id =_this.data._id ;
    var page = _this.data.page + 1;
    _this.setData({
      page: page,
    })
    console.log("获取的ID" ,id)
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: _this.data.http_api + 'product/al',
      data: { id: id, page: page },
      method: 'post',
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      success: function (res) {
        wx.hideLoading();
        if (res.data.ggtop == null) {
          _this.setData({
         
            f: false,
          })
        } else {
          _this.setData({
            imgList: _this.data.imgList.concat(res.data.ggtop),
            f: true
          })
        }



      }
    })
  }
})