// pages/newslist/newslist.js
//获取应用实例
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    newsList:null,
    page:1,
    totalPage: null,
    phone: app.globalData.phone,
  },

 get_news_list:function(){

 },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
      wx.request({
        url: "https://xcxapi.dq3c.net/xcx_get_news_list.php",
        method: "POST",
        data: {
          news_type: "",
          page: 1,
          limit: "10"
        },
        header: {
          'content-type': 'application/x-www-form-urlencoded'
        },
        success: function (res) {
          that.setData({
            newsList: res.data.list,
            totalPage: res.data.totalpage
          })

        }
      })

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

    var that = this;
    var page = that.data.page + 1;
    that.setData({
      page: page,
    })
    if (page <= that.data.totalPage) {
      wx.showLoading({
        title: '加载中',
      })
      wx.request({
        url: "https://xcxapi.dq3c.net/xcx_get_news_list.php",
        method: "POST",
        data: {
          news_type: "",
          page: page,
          limit: "10"
        },
        header: {
          'content-type': 'application/x-www-form-urlencoded'
        },
        success: function (res) {
          wx.hideLoading()
          that.setData({
            newsList: that.data.newsList.concat(res.data.list)

          })
        },
        fail: function (res) {
          wx.hideLoading()
        }
      })

    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  findphone: function () {
    var that = this
    var dailishangid = wx.getStorageSync('dailishangid');
    if (dailishangid != null && dailishangid != "") {
      var daili_info = wx.getStorageSync('dailishang_info');
      var phone = daili_info.linkus_telephone;
    } else {
      var phone = that.data.phone;
    }
    wx.makePhoneCall({
      phoneNumber: phone //仅为示例，并非真实的电话号码
    })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})