//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    models:[
      [
        {
          text:"品牌展示"
        },
        {
          text: "商城网站"
        },
        {
           text: "行业平台"
        },
        {
          text: "供求管理"
        },
        {
          text: "子网管理"
        },
        {
          text: "关联资讯"
        }
      ],
      [
        {
          text: "产品管理"
        },
        {
          text: "订单管理"
        },
        {
          text: "资讯管理"
        },
        {
          text: "产品推荐"
        },
        {
          text: "物流管理"
        },
        {
          text: "微信支付"
        }
      ],
      [
        {
          text: "会员管理"
        },
        {
          text: "门店管理"
        },
        {
          text: "在线客服"
        },
        {
          text: "图文导航"
        },
        {
          text: "轮播图"
        },
        {
          text: "文字导航"
        }
      ],
      [
        {
          text: "一键拨号"
        },
        {
          text: "行业模板"
        },
        {
          text: "专属模板"
        },
        {
          text: "广告图"
        },
        {
          text: "滚动广告"
        },
        {
          text: "网站导航"
        }
      ], 
      [
        {
          text: "在线地图"
        },
        {
          text: "10+配色"
        },
        {
          text: "表单工具"
        },
        {
          text: "智能留言"
        },
        {
          text: "预约到店"
        },
        {
          text: "线下付款"
        }
      ]

     
    ],
    // demoList: [
    //   {
    //     url: "https://xcxapi.dq3c.net/xcxapi/images/xcx-22.jpg"
    //   },
    //   {
    //     url: "https://xcxapi.dq3c.net/wxsp_ht/images/upload/case/1504337535.jpg"
    //   },
    //   {
    //     url: "https://xcxapi.dq3c.net/wxsp_ht/images/upload/case/1504337037.jpg"
    //   },
    //   {
    //     url: "https://xcxapi.dq3c.net/wxsp_ht/images/upload/case/1504336504.jpg"
    //   }
    // ],
    demoList: [
      {
        url: "https://xcxshop.dq3c.net/Public/fire/02.jpg"
      },
      {
        url: "https://xcxshop.dq3c.net/Public/fire/01.jpg"
      },
      {
        url: "https://xcxshop.dq3c.net/Public/fire/04.jpg"
      },
      {
        url: "https://xcxshop.dq3c.net/Public/fire/03.jpg"
      }
    ],
    indicatorDots: true,
    autoplay: true,
    interval: 4000,
    duration: 1000,
    circular: true,
    region: ['选择省', '选择市', '选择区'],
    customItem: '全部'

  },

  formSubmit: function (e) {
    var that = this
    wx.request({
      url: "https://xcxapi.dq3c.net/wxsp_ht/company_info/save_contact_us.php",
      method: "POST",
      data: {
        name: e.detail.value.name,
        phone: e.detail.value.phone,
        wechat: e.detail.value.wechat,
        content: e.detail.value.content,
        province: e.detail.value.city[0],
        city: e.detail.value.city[1],
        area: e.detail.value.city[2],
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        if (res.data.code == 200) {
          wx.showToast({
            title: '提交成功',
            icon: 'success',
            duration: 2000
          })
        } else {
          wx.showModal({
            title: '提示',
            content: res.data.desc,
            success: function (res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
          setTimeout(function () {
            wx.hideLoading()
          }, 2000)
        }
      }
    })
  },
  bindRegionChange: function (e) {
    this.setData({
      region: e.detail.value
    })
  },
  yl:function(e){
    var src = e.currentTarget.dataset.src;
    wx.previewImage({
      urls: [src],
    })
  }


})
