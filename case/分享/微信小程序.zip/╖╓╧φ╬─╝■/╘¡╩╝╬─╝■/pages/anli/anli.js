//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    ImgUrls: [
      {
        url: 'https://xcxapi.dq3c.net/wxsp_ht/images/upload/company/1506414498.jpg'
      },
      {
        url: 'https://xcxapi.dq3c.net/wxsp_ht/images/upload/company/1506414671.jpg'
      },
      {
        url: 'https://xcxapi.dq3c.net/wxsp_ht/images/upload/company/1506414686.jpg'
      },
      {
        url: 'https://xcxapi.dq3c.net/wxsp_ht/images/upload/company/1506414518.jpg'
      },
      {
        url: 'https://xcxapi.dq3c.net/wxsp_ht/images/upload/company/1506414702.jpg'
      },
      {
        url: 'https://xcxapi.dq3c.net/wxsp_ht/images/upload/company/1506414723.jpg'
      }
    ],
    anliImg1:[
      {
        url:'https://xcxapi.dq3c.net/xcxapi/images/anli/anli_03.jpg'
      },
      {
        url: 'https://xcxapi.dq3c.net/xcxapi/images/anli/anli_05.jpg'
      },
      {
        url: 'https://xcxapi.dq3c.net/xcxapi/images/anli/anli_07.jpg'
      }
    ],
    anliImg2: [
      {
        url: 'https://xcxapi.dq3c.net/xcxapi/images/anli/anli_10.jpg'
      },
      {
        url: 'https://xcxapi.dq3c.net/xcxapi/images/anli/anli_12.jpg'
      },
      {
        url: 'https://xcxapi.dq3c.net/xcxapi/images/anli/anli_14.jpg'
      },
      {
        url: 'https://xcxapi.dq3c.net/xcxapi/images/anli/anli_16.jpg'
      },
      {
        url: 'https://xcxapi.dq3c.net/xcxapi/images/anli/anli_18.jpg'
      }
    ],
   
    indicatorDots: true,
    autoplay: true,
    interval: 4000,
    duration: 1000,
    circular: true

  }
})
