//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    userInfo: {},
    hasUserInfo: false,
    name: app.globalData.name,
    address: app.globalData.address,
    dailishangid: app.globalData.dailishangid,
    phone:app.globalData.phone,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    formdata: {
      name: app.globalData.formdata.name,
      phone: app.globalData.formdata.phone,
      wechat: app.globalData.formdata.wechat,
      content: app.globalData.formdata.content,
      province: app.globalData.formdata.province,
      city: app.globalData.formdata.city,
      area: app.globalData.formdata.area
    },
    zzImgUrls:[
      {
        url: 'https://xcxapi.dq3c.net/xcxapi/images/t-01.jpg'
      }, 
      {
        url: 'https://xcxapi.dq3c.net/xcxapi/images/t-02.jpg'
      }, 
      {
        url: 'https://xcxapi.dq3c.net/xcxapi/images/t-03.jpg'
      },
      {
        url: 'https://xcxapi.dq3c.net/xcxapi/images/t-04.jpg'
      }
    ],
    flexItem:[
      {
        navigatorUrl:"/pages/haochu/haochu",
        imgUrl: "/icons/flex1.png",
        text:"好处"
      },
      {
        navigatorUrl: "/pages/youshi/youshi",
        imgUrl: "/icons/flex2.png",
        text: "优势"
      },
      {
        navigatorUrl: "/pages/gongneng/gongneng",
        imgUrl: "/icons/flex3.png",
        text: "功能"
      },
      {
        navigatorUrl: "/pages/smallApp/smallApp",
        imgUrl: "/icons/flex4.png",
        text: "小程序"
      },
      {
        navigatorUrl: "/pages/jiameng/jiameng",
        imgUrl: "/icons/flex5.png",
        text: "招商加盟"
      },
      {
        navigatorUrl: "/pages/newAnli/newAnli",
        imgUrl: "/icons/flex6.png",
        text: "经典案例"
      }
    ],
    goodList:[
      {
        dtTxt: "入口",
        ddTxt:"大流量入口",
        ddTxts1: "共享9亿微信活跃用户",
        ddTxts2: "有流量就有顾客"
      },
      {
        dtTxt: "门槛低",
        ddTxt: "使用门槛低",
        ddTxts1: "有微信就能用",
        ddTxts2: "无需安装下载，用完即走"
      },
      {
        dtTxt: "成本低",
        ddTxt: "开发成本低",
        ddTxts1: "无需烧钱定制APP",
        ddTxts2: "更省成本"
      },
      {
        dtTxt: "体验好",
        ddTxt: "用户体验好",
        ddTxts1: "功能丰富",
        ddTxts2: "与原生APP体验无异样"
      },
      {
        dtTxt: "优势",
        ddTxt: "线下场景优势",
        ddTxts1: "连接更多用户",
        ddTxts2: "彻底打通O2O"
      },
      {
        dtTxt: "渠道",
        ddTxt: "移动化推广渠道",
        ddTxts1: "多种入口",
        ddTxts2: "更多移动化推广渠道"
      }

    ],
    demoList:[
      {
        url:"https://xcxshop.dq3c.net/Public/fire/02.jpg"
      },
      {
        url: "https://xcxshop.dq3c.net/Public/fire/01.jpg"
      },
      {
        url: "https://xcxshop.dq3c.net/Public/fire/04.jpg"
      },
      {
        url: "https://xcxshop.dq3c.net/Public/fire/03.jpg"
      }
    ],
    storeList:[
      {
        url:""
      }
    ],
    indicatorDots: true,
    autoplay: true,
    interval: 4000,
    duration: 1000,
    circular:true,
    region: ['选择省', '选择市', '选择区'],
    customItem: '全部'
      
  },
  //事件处理函数
  bindViewTap: function() {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  onLoad: function (options) {
   if(options.id!=""&&options.id!=null){
        wx.request({
          url: "https://xcxapi.dq3c.net/xcxapi/dailishang/dali_info.php",
          method: "GET",
          data: {
            id: options.id,
          },
          header: {
            'content-type': 'application/x-www-form-urlencoded'
          },
          success: function (res) {
          if(res.data.success=="success"&&res.data.list!=""){
            wx.setStorageSync('dailishangid', options.id);
            wx.setStorageSync('dailishang_info', res.data.list);

          }
          }      
        })      
   }
    var dailishangid = wx.getStorageSync('dailishangid');
    if(dailishangid!=""){
      this.setData({
        dailishangid: wx.getStorageSync('dailishangid')
      })
    }

    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse){
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    }
  },

  findmap:function(){
    var that = this
    wx.openLocation({
      latitude: 39.952724851696836,
      longitude: 116.30883615211486,
      name:that.data.name,
      address: that.data.address,
      scale: 28
    })

  },

  findphone:function(){
    var that=this
    var dailishangid = wx.getStorageSync('dailishangid');
    if (dailishangid != null && dailishangid!=""){
      var daili_info = wx.getStorageSync('dailishang_info');
      var phone = daili_info.linkus_telephone;
    }else{
      var phone = that.data.phone;
    }
    wx.makePhoneCall({
      phoneNumber: phone //仅为示例，并非真实的电话号码
    })
  },

  formSubmit: function (e) {
      var that = this
      wx.request({
        url: "https://xcxapi.dq3c.net/wxsp_ht/company_info/save_contact_us.php",
        method: "POST",
        data: {
          name: e.detail.value.name,
          phone: e.detail.value.phone,
          wechat: e.detail.value.wechat,
          content: e.detail.value.content,
          province: e.detail.value.city[0],
          city: e.detail.value.city[1],
          area: e.detail.value.city[2],
        },
        header: {
          'content-type': 'application/x-www-form-urlencoded'
        },
        success: function (res) {
            if(res.data.code==200){
              wx.showToast({
                title: '提交成功',
                icon: 'success',
                duration: 2000
              })  
            }else{
              wx.showModal({
                title: '提示',
                content: res.data.desc,
                success: function (res) {
                  if (res.confirm) {
                    console.log('用户点击确定')
                  } else if (res.cancel) {
                    console.log('用户点击取消')
                  }
                }
              })
              setTimeout(function () {
                wx.hideLoading()
              }, 2000)
            }
        }
      })
  },

  constact_us:function(){
    var that = this
    wx.makePhoneCall({
      phoneNumber: that.data.phone //仅为示例，并非真实的电话号码
    })      
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  onPullDownRefresh: function () {
    wx.showNavigationBarLoading()
    wx.hideNavigationBarLoading()
    wx.stopPullDownRefresh()
  },

  getUserInfo: function(e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },
  bindRegionChange: function (e) {
    this.setData({
      region: e.detail.value
    })
  },
  tz:function(event){
    console.log(111)
    wx.navigateTo({
      url: event.currentTarget.dataset.url//实际路径要写全
    })
  },
  makePhone:function(e){
    var phones=e.target.dataset.phone;
    wx.makePhoneCall({
      phoneNumber: phones 
    })
  },

  //经典案例预览
  imgshow:function(e){
    var src = e.currentTarget.dataset.src;
    wx.previewImage({
      urls: [src],
    })
  }
})
